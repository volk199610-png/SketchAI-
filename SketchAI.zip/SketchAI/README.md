# Sketch AI

Android-приложение: короткая идея → сценарий → чёрно-белые sketch-кадры → озвучка → субтитры → MP4.
Kotlin · Jetpack Compose · Material 3 · Room · OkHttp · kotlinx.serialization · MediaCodec.

> Важно: проект написан без возможности запустить Gradle (в среде автора нет Android SDK),
> поэтому **ни разу не компилировался**. Если сборка выдаст ошибки, пришлите лог — это обычные правки.

## 1. Открыть и собрать
1. Android Studio Ladybug (2024.2) или новее, JDK 17+ (встроенный JBR подходит).
2. `File → Open` → папка `SketchAI`. Дождитесь Gradle Sync (скачает SDK 35 и зависимости).
3. Запуск на устройстве: кнопка **Run** (minSdk 26).
4. APK из терминала:
   ```
   ./gradlew assembleDebug
   ```
   Результат: `app/build/outputs/apk/debug/app-debug.apk`
5. Без Android Studio: загрузите проект в репозиторий GitHub — workflow `.github/workflows/build.yml`
   соберёт APK, скачайте его во вкладке **Actions → Artifacts**.

## 2. Release APK
```
keytool -genkey -v -keystore sketchai.jks -alias sketchai -keyalg RSA -keysize 2048 -validity 10000
./gradlew assembleRelease
apksigner sign --ks sketchai.jks --out app-release-signed.apk app/build/outputs/apk/release/app-release-unsigned.apk
```
Либо `Build → Generate Signed Bundle / APK` в Android Studio.

## 3. Как приложение работает
| Шаг | Реализация | Без backend |
|---|---|---|
| Сценарий | `ComedyEngine` → `LlmScriptProvider` (`POST {url}/chat/completions`) | `OfflineScriptProvider` режет вашу идею на setup / build-up / pause / punchline |
| Кадры | `ImageGenerationProvider`: ComfyUI, OpenAI-совместимый, **локальный Canvas-скетч** | локальный скетч (стикмены с волосами, очками, шляпой…) |
| Анимация | `VideoGenerationProvider` → `LocalBoilVideoProvider` (дрожание линий + наезд) | работает всегда |
| Голос | `VoiceGenerationProvider`: Android TTS или `POST {url}/audio/speech` | Android TTS |
| Субтитры | `FrameRenderer` (шрифт, размер, позиция, фон, анимация) | работает всегда |
| Экспорт | `VideoExporter`: MediaCodec H.264 + AAC + MediaMuxer, 30 FPS → MediaStore `Movies/SketchAI` | работает всегда |

Preview и экспорт рисуются одним и тем же `FrameRenderer`, поэтому совпадают.
Все стилевые теги (`black and white minimalist hand drawn sketch`, `clean black ink outlines` …) добавляет `StylePromptBuilder`.
Длительность сцены = max(заданная вами, длина озвучки + пауза).

## 4. Подключение ComfyUI
1. Запустите ComfyUI с доступом из сети: `python main.py --listen 0.0.0.0` (порт 8188).
2. Телефон и ПК в одной сети. В **Settings → ComfyUI URL**: `http://192.168.x.x:8188`.
3. **Checkpoint file name** — точное имя файла из `ComfyUI/models/checkpoints` (по умолчанию `sd_xl_base_1.0.safetensors`).
4. **Image generation backend** → `ComfyUI`. Нажмите **Test connection** (проверяет `/system_stats`).
5. Рекомендуется LoRA/чекпоинт в стиле line-art: стиль сильнее держится.
6. Свой workflow: в ComfyUI `Save (API Format)`, вставьте JSON в поле *Custom workflow*, а на месте значений
   поставьте `%PROMPT% %NEGATIVE% %WIDTH% %HEIGHT% %SEED% %CHECKPOINT%`.
   Приложение отправит `POST /prompt`, опросит `/history/{id}` и скачает картинку через `/view`.

## 5. Backend / API key
- **Backend URL** — любой OpenAI-совместимый сервер: `https://api.openai.com/v1`, Ollama `http://host:11434/v1`,
  LM Studio, vLLM, OpenRouter и т. п. Нужны эндпоинты:
  - `POST /chat/completions` — сценарий (поле *Script model*),
  - `POST /images/generations` — картинки (если выбран бэкенд OpenAI),
  - `POST /audio/speech` с `response_format: wav` — озвучка (если включён *Use backend TTS*).
- **API key** вводится на устройстве и хранится в `EncryptedSharedPreferences` (Android Keystore).
  В исходниках и в APK ключей нет. Для продакшена лучше поставить свой backend-proxy и указать его URL.
- **Test connection** запрашивает `GET /models`.

## 6. Какие API нужны для полной AI-генерации
1. LLM для сценария (OpenAI / Anthropic через совместимый прокси / Ollama).
2. Генератор картинок (ComfyUI + SDXL/LoRA line-art, или OpenAI Images).
3. TTS (OpenAI TTS или любой совместимый; иначе встроенный Android TTS).
4. (Опционально, будущее) image-to-video: добавьте реализацию `VideoGenerationProvider`.

## 7. Структура
```
app/src/main/java/com/sketchai/app/
  ai/            ComedyEngine, StylePromptBuilder, CharacterFactory, провайдеры картинок, ImageService
  audio/         TTS-провайдеры, VoiceService, WavUtils, AudioMixer, LinePlayer
  video/         Timeline, FrameRenderer, VideoGenerationProvider, VideoExporter
  data/          SettingsRepository, ProjectRepository
  database/      Room: ProjectEntity, ProjectDao, AppDatabase
  domain/        модели (Project, Scene, Character, SubtitleStyle…)
  network/       ApiClient (OkHttp) + AiException (типизированные ошибки)
  presentation/  ViewModel'и
  ui/            Compose-экраны: Home, Projects, Settings, Project (Script / Characters / Preview)
  di/            AppContainer (ручной DI — без kapt/Hilt, меньше рисков сборки)
  utils/         ProjectFiles, MediaStoreSaver
```

## 8. Развитие
- Реальное видео: реализуйте `VideoGenerationProvider.createClip` (AnimateDiff / SVD через ComfyUI) и возвращайте `SceneClip`.
- Другие стили: добавьте теги в `StylePromptBuilder` и enum стиля в `Project`.
- Фоновая музыка: подмешивайте дорожку в `AudioMixer.mix`.
- Тесты: `TimelineBuilder`, `WavUtils`, `OfflineScriptProvider` — чистый Kotlin, легко покрыть unit-тестами.

## 9. Известные ограничения
- Не проверялось на устройстве. Кодеки: H.264 1080p нужен аппаратному энкодеру (есть почти везде).
- Android 8–9: видео сохраняется в `Android/data/com.sketchai.app/files/Movies` (без галереи), на 10+ — в `Movies/SketchAI`.
- Казахский TTS зависит от установленного движка; при отсутствии используется язык устройства.
- Отмена экспорта/генерации — кнопка Cancel в панели прогресса.
