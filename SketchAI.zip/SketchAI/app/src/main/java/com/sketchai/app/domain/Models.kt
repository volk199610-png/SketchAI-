package com.sketchai.app.domain

import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json
import java.util.UUID

object AppJson {
    val instance = Json {
        ignoreUnknownKeys = true
        encodeDefaults = true
        coerceInputValues = true
        isLenient = true
    }
}

@Serializable
enum class Genre { BLACK_HUMOR, ABSURD, SARCASM, REGULAR }

@Serializable
enum class AspectFormat(val w: Int, val h: Int, val genW: Int, val genH: Int, val label: String) {
    PORTRAIT(1080, 1920, 768, 1344, "9:16"),
    LANDSCAPE(1920, 1080, 1344, 768, "16:9"),
    SQUARE(1080, 1080, 1024, 1024, "1:1");

    val ratio: Float get() = w.toFloat() / h.toFloat()
}

@Serializable
enum class Beat { SETUP, BUILD_UP, PAUSE, PUNCHLINE, ENDING }

enum class VoicePreset(val pitch: Float, val rate: Float, val remoteVoice: String) {
    MALE_CALM(0.85f, 0.95f, "onyx"),
    MALE_NERVOUS(1.05f, 1.2f, "echo"),
    FEMALE_CALM(1.15f, 1.0f, "nova"),
    FEMALE_BRIGHT(1.3f, 1.1f, "shimmer");

    fun toProfile() = VoiceProfile(pitch, rate, remoteVoice, name)
}

@Serializable
data class VoiceProfile(
    val pitch: Float = 1f,
    val rate: Float = 1f,
    val remoteVoice: String = "alloy",
    val preset: String = "",
)

@Serializable
data class Character(
    val id: String,
    val name: String,
    val gender: String = "male",
    val age: String = "35",
    val hair: String = "short messy hair",
    val face: String = "round face, dot eyes",
    val body: String = "thin body",
    val clothes: String = "plain shirt",
    val accessories: String = "",
    val personality: String = "calm",
    val visualDescription: String = "",
    val voice: VoiceProfile = VoiceProfile(),
) {
    /** Text used inside every image prompt so the character keeps its look between scenes. */
    fun promptDescription(): String {
        val base = visualDescription.ifBlank {
            listOf(gender, "age $age", hair, face, body, clothes, accessories)
                .filter { it.isNotBlank() }.joinToString(", ")
        }
        return "$name ($id): $base"
    }

    fun traitsText(): String = "$hair $face $clothes $accessories $visualDescription".lowercase()
}

@Serializable
data class DialogueLine(val characterId: String, val text: String)

@Serializable
data class Scene(
    val id: String = UUID.randomUUID().toString(),
    val beat: Beat = Beat.BUILD_UP,
    val durationSec: Float = 5f,
    val characterIds: List<String> = emptyList(),
    val action: String = "",
    val dialogue: List<DialogueLine> = emptyList(),
    val imageFile: String? = null,
)

@Serializable
enum class SubtitleFont { SANS, SERIF, MONO, HAND }

@Serializable
enum class SubtitlePosition { TOP, CENTER, BOTTOM }

@Serializable
enum class SubtitleLook { BLACK_ON_WHITE, WHITE_STROKE }

@Serializable
enum class SubtitleAnim { NONE, FADE, TYPEWRITER }

@Serializable
data class SubtitleStyle(
    val font: SubtitleFont = SubtitleFont.SANS,
    /** Size in pixels for a 1080px reference frame. */
    val size: Int = 52,
    val position: SubtitlePosition = SubtitlePosition.BOTTOM,
    val background: Boolean = true,
    val look: SubtitleLook = SubtitleLook.BLACK_ON_WHITE,
    val anim: SubtitleAnim = SubtitleAnim.FADE,
)

@Serializable
data class Project(
    val id: Long = 0,
    val title: String,
    val createdAt: Long,
    val idea: String,
    val genre: Genre,
    val humorLevel: Int,
    val targetDurationSec: Int,
    val format: AspectFormat,
    val characters: List<Character>,
    val scenes: List<Scene>,
    val subtitle: SubtitleStyle = SubtitleStyle(),
) {
    val totalDurationSec: Float get() = scenes.fold(0f) { acc, s -> acc + s.durationSec }
}

data class ComedyRequest(
    val idea: String,
    val humorLevel: Int,
    val genre: Genre,
    val durationSec: Int,
    val characterCount: Int,
    val defaultVoice: Int = 0,
)

data class ComedyResult(
    val title: String,
    val characters: List<Character>,
    val scenes: List<Scene>,
    val usedFallback: Boolean = false,
)
