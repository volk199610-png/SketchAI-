package com.sketchai.app.utils

import android.content.ContentValues
import android.content.Context
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

data class ExportResult(val uri: Uri?, val location: String)

object MediaStoreSaver {
    /**
     * API 29+: goes to Movies/SketchAI through MediaStore (no permission needed).
     * API 26-28: copies to the app's external Movies folder (no permission needed, not in the gallery).
     */
    suspend fun saveVideo(context: Context, source: File, displayName: String): ExportResult =
        withContext(Dispatchers.IO) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val values = ContentValues().apply {
                    put(MediaStore.Video.Media.DISPLAY_NAME, displayName)
                    put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
                    put(MediaStore.Video.Media.RELATIVE_PATH, Environment.DIRECTORY_MOVIES + "/SketchAI")
                    put(MediaStore.Video.Media.IS_PENDING, 1)
                }
                val resolver = context.contentResolver
                val uri = resolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values)
                    ?: throw IllegalStateException("MediaStore insert failed")
                resolver.openOutputStream(uri)?.use { out -> source.inputStream().use { it.copyTo(out) } }
                    ?: throw IllegalStateException("Cannot open output stream")
                val done = ContentValues().apply { put(MediaStore.Video.Media.IS_PENDING, 0) }
                resolver.update(uri, done, null, null)
                ExportResult(uri, "Movies/SketchAI/$displayName")
            } else {
                val dir = context.getExternalFilesDir(Environment.DIRECTORY_MOVIES) ?: context.filesDir
                dir.mkdirs()
                val target = File(dir, displayName)
                source.copyTo(target, overwrite = true)
                ExportResult(null, target.absolutePath)
            }
        }
}
