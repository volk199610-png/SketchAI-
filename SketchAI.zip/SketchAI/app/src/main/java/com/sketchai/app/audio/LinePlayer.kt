package com.sketchai.app.audio

import android.media.MediaPlayer
import java.io.File

/** Plays one voice clip at a time during the in-app preview. */
class LinePlayer {
    private var mp: MediaPlayer? = null

    fun play(file: File) {
        stop()
        try {
            val p = MediaPlayer()
            p.setDataSource(file.path)
            p.setOnCompletionListener { done ->
                runCatching { done.release() }
                if (mp === done) mp = null
            }
            p.prepare()
            p.start()
            mp = p
        } catch (e: Exception) {
            mp = null
        }
    }

    fun stop() {
        mp?.let { runCatching { it.release() } }
        mp = null
    }
}
