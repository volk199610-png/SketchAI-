package com.sketchai.app.ui

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.sketchai.app.data.ThemeMode

private val Light = lightColorScheme(
    primary = Color(0xFF111111), onPrimary = Color.White,
    primaryContainer = Color(0xFFE6E6E6), onPrimaryContainer = Color(0xFF111111),
    secondary = Color(0xFF555555), onSecondary = Color.White,
    secondaryContainer = Color(0xFF111111), onSecondaryContainer = Color.White,
    tertiary = Color(0xFF777777), onTertiary = Color.White,
    background = Color.White, onBackground = Color(0xFF111111),
    surface = Color.White, onSurface = Color(0xFF111111),
    surfaceVariant = Color(0xFFF1F1F1), onSurfaceVariant = Color(0xFF555555),
    surfaceTint = Color.Transparent,
    surfaceContainerLowest = Color.White, surfaceContainerLow = Color(0xFFF7F7F7),
    surfaceContainer = Color(0xFFF2F2F2), surfaceContainerHigh = Color(0xFFEDEDED),
    surfaceContainerHighest = Color(0xFFE6E6E6),
    outline = Color(0xFF8A8A8A), outlineVariant = Color(0xFFD0D0D0),
    error = Color(0xFFB00020), onError = Color.White,
    errorContainer = Color(0xFFEAEAEA), onErrorContainer = Color(0xFF111111),
)

private val Dark = darkColorScheme(
    primary = Color.White, onPrimary = Color(0xFF111111),
    primaryContainer = Color(0xFF2B2B2B), onPrimaryContainer = Color.White,
    secondary = Color(0xFFBDBDBD), onSecondary = Color(0xFF111111),
    secondaryContainer = Color.White, onSecondaryContainer = Color(0xFF111111),
    tertiary = Color(0xFF9E9E9E), onTertiary = Color(0xFF111111),
    background = Color(0xFF0B0B0B), onBackground = Color.White,
    surface = Color(0xFF0B0B0B), onSurface = Color.White,
    surfaceVariant = Color(0xFF1C1C1C), onSurfaceVariant = Color(0xFFBDBDBD),
    surfaceTint = Color.Transparent,
    surfaceContainerLowest = Color.Black, surfaceContainerLow = Color(0xFF121212),
    surfaceContainer = Color(0xFF161616), surfaceContainerHigh = Color(0xFF1E1E1E),
    surfaceContainerHighest = Color(0xFF262626),
    outline = Color(0xFF777777), outlineVariant = Color(0xFF3A3A3A),
    error = Color(0xFFFF8A80), onError = Color.Black,
    errorContainer = Color(0xFF2B2B2B), onErrorContainer = Color.White,
)

@Composable
fun SketchTheme(mode: ThemeMode, content: @Composable () -> Unit) {
    val dark = when (mode) {
        ThemeMode.SYSTEM -> isSystemInDarkTheme()
        ThemeMode.LIGHT -> false
        ThemeMode.DARK -> true
    }
    MaterialTheme(
        colorScheme = if (dark) Dark else Light,
        shapes = Shapes(
            extraSmall = RoundedCornerShape(4.dp), small = RoundedCornerShape(6.dp),
            medium = RoundedCornerShape(10.dp), large = RoundedCornerShape(14.dp),
        ),
        content = content,
    )
}
