package com.sketchai.app.presentation

import androidx.annotation.StringRes
import com.sketchai.app.R
import com.sketchai.app.network.AiException
import kotlinx.coroutines.CancellationException

/** A message the UI can render: a string resource plus optional technical detail. */
data class UiMessage(
    @StringRes val resId: Int,
    val detail: String? = null,
    val offerSettings: Boolean = false,
    val isError: Boolean = true,
)

fun Throwable.toUiMessage(): UiMessage {
    if (this is CancellationException) return UiMessage(R.string.msg_cancelled, isError = false)
    val d = message?.takeIf { it.isNotBlank() }
    if (this is AiException) {
        return when (kind) {
            AiException.Kind.CONNECTION -> UiMessage(R.string.err_connection, d, true)
            AiException.Kind.TIMEOUT -> UiMessage(R.string.err_timeout, d, true)
            AiException.Kind.INVALID_KEY -> UiMessage(R.string.err_invalid_key, d, true)
            AiException.Kind.GENERATION_FAILED -> UiMessage(R.string.err_generation, d)
            AiException.Kind.SERVER_UNAVAILABLE -> UiMessage(R.string.err_server, d, true)
            AiException.Kind.INVALID_RESPONSE -> UiMessage(R.string.err_invalid_response, d)
            AiException.Kind.NOT_CONFIGURED -> UiMessage(R.string.err_not_configured, d, true)
        }
    }
    return UiMessage(R.string.err_generation, d)
}
