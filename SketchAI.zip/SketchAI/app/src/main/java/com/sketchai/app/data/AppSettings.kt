package com.sketchai.app.data

import com.sketchai.app.domain.AspectFormat
import java.util.Locale

enum class ImageBackend { LOCAL, COMFYUI, OPENAI }
enum class ThemeMode { SYSTEM, LIGHT, DARK }

data class AppSettings(
    val backendUrl: String = "",
    val apiKey: String = "",
    val llmModel: String = "gpt-4o-mini",
    val imageModel: String = "dall-e-3",
    val ttsModel: String = "tts-1",
    val comfyUrl: String = "",
    val comfyCheckpoint: String = "sd_xl_base_1.0.safetensors",
    val comfyWorkflow: String = "",
    val imageBackend: ImageBackend = ImageBackend.LOCAL,
    val remoteTts: Boolean = false,
    val defaultDuration: Int = 15,
    val defaultFormat: AspectFormat = AspectFormat.PORTRAIT,
    val defaultVoice: Int = 0,
    val defaultHumor: Int = 70,
    val themeMode: ThemeMode = ThemeMode.SYSTEM,
    val language: String = defaultLanguage(),
) {
    val backendConfigured: Boolean get() = backendUrl.isNotBlank()
    val comfyConfigured: Boolean get() = comfyUrl.isNotBlank()

    companion object {
        fun defaultLanguage(): String = when (Locale.getDefault().language) {
            "ru" -> "ru"
            "kk" -> "kk"
            else -> "en"
        }
    }
}
