package com.sketchai.app.network

class AiException(val kind: Kind, detail: String = "") : Exception(detail) {
    enum class Kind { CONNECTION, TIMEOUT, INVALID_KEY, GENERATION_FAILED, SERVER_UNAVAILABLE, INVALID_RESPONSE, NOT_CONFIGURED }
}
