package com.sketchai.app.presentation

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import androidx.annotation.StringRes
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.sketchai.app.R
import com.sketchai.app.ai.CharacterFactory
import com.sketchai.app.audio.AudioMixer
import com.sketchai.app.di.AppContainer
import com.sketchai.app.domain.AspectFormat
import com.sketchai.app.domain.Beat
import com.sketchai.app.domain.Character
import com.sketchai.app.domain.DialogueLine
import com.sketchai.app.domain.Project
import com.sketchai.app.domain.Scene
import com.sketchai.app.domain.SubtitleStyle
import com.sketchai.app.domain.VoiceProfile
import com.sketchai.app.utils.ExportResult
import com.sketchai.app.utils.MediaStoreSaver
import com.sketchai.app.video.FrameRenderer
import com.sketchai.app.video.Timeline
import com.sketchai.app.video.TimelineBuilder
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

data class ProjectState(
    val project: Project? = null,
    val loading: Boolean = true,
    @StringRes val busyText: Int? = null,
    val progress: Float? = null,
    val message: UiMessage? = null,
    val timeline: Timeline = Timeline(emptyList()),
    val bitmaps: Map<String, Bitmap> = emptyMap(),
    val export: ExportResult? = null,
)

class ProjectViewModel(private val c: AppContainer, private val projectId: Long) : ViewModel() {

    private val _state = MutableStateFlow(ProjectState())
    val state: StateFlow<ProjectState> = _state.asStateFlow()

    private val voiceCache = HashMap<String, File>()
    private var saveJob: Job? = null
    private var workJob: Job? = null

    init {
        viewModelScope.launch { load() }
    }

    // ---- loading / saving ---------------------------------------------------------------------

    private suspend fun load() {
        val p = c.projects.load(projectId)
        if (p == null) {
            _state.update { it.copy(loading = false, message = UiMessage(R.string.err_project_missing)) }
            return
        }
        val bitmaps = loadBitmaps(p)
        primeVoiceCache(p)
        _state.update { it.copy(project = p, loading = false, bitmaps = bitmaps, timeline = rebuild(p)) }
    }

    private suspend fun loadBitmaps(p: Project): Map<String, Bitmap> = withContext(Dispatchers.IO) {
        val map = HashMap<String, Bitmap>()
        for (s in p.scenes) {
            val name = s.imageFile ?: continue
            val f = c.files.imageFile(p.id, name)
            if (!f.exists()) continue
            val bmp = runCatching { BitmapFactory.decodeFile(f.path) }.getOrNull() ?: continue
            map[s.id] = bmp
        }
        map
    }

    private fun voiceOf(p: Project, dl: DialogueLine): VoiceProfile =
        p.characters.find { it.id == dl.characterId }?.voice ?: VoiceProfile()

    private fun primeVoiceCache(p: Project) {
        val dir = c.files.audioDir(p.id)
        for (sc in p.scenes) for (dl in sc.dialogue) {
            val v = voiceOf(p, dl)
            val f = c.voice.fileFor(dir, dl.text, v)
            if (f.exists() && f.length() > 44) voiceCache[c.voice.keyFor(dl.text, v)] = f
        }
    }

    private fun rebuild(p: Project): Timeline =
        TimelineBuilder.build(p) { text, voice -> voiceCache[c.voice.keyFor(text, voice)] }

    private fun scheduleSave() {
        saveJob?.cancel()
        saveJob = c.appScope.launch {
            delay(500)
            _state.value.project?.let { c.projects.save(it) }
        }
    }

    override fun onCleared() {
        c.appScope.launch { _state.value.project?.let { c.projects.save(it) } }
        super.onCleared()
    }

    private fun edit(f: (Project) -> Project) {
        val cur = _state.value.project ?: return
        val next = f(cur)
        _state.update { it.copy(project = next, timeline = rebuild(next), export = null) }
        scheduleSave()
    }

    fun dismissMessage() = _state.update { it.copy(message = null) }

    // ---- script editing -----------------------------------------------------------------------

    fun setTitle(title: String) = edit { it.copy(title = title) }

    fun updateScene(id: String, f: (Scene) -> Scene) =
        edit { p -> p.copy(scenes = p.scenes.map { if (it.id == id) f(it) else it }) }

    fun deleteScene(id: String) {
        val p = _state.value.project ?: return
        if (p.scenes.size <= 1) return
        p.scenes.find { it.id == id }?.imageFile?.let { c.files.imageFile(p.id, it).delete() }
        edit { it.copy(scenes = it.scenes.filter { s -> s.id != id }) }
        _state.update { it.copy(bitmaps = it.bitmaps - id) }
    }

    fun addScene() = edit { p ->
        p.copy(scenes = p.scenes + Scene(beat = Beat.BUILD_UP, durationSec = 4f, characterIds = p.characters.map { it.id }))
    }

    fun moveScene(id: String, delta: Int) = edit { p ->
        val list = p.scenes.toMutableList()
        val i = list.indexOfFirst { it.id == id }
        val j = i + delta
        if (i < 0 || j < 0 || j >= list.size) p else {
            val tmp = list[i]; list[i] = list[j]; list[j] = tmp
            p.copy(scenes = list)
        }
    }

    // ---- characters ---------------------------------------------------------------------------

    fun updateCharacter(id: String, f: (Character) -> Character) =
        edit { p -> p.copy(characters = p.characters.map { if (it.id == id) f(it) else it }) }

    fun addCharacter(defaultName: String) = edit { p ->
        val idx = p.characters.size
        val ch = CharacterFactory.default(idx, defaultName, c.settings.state.value.defaultVoice)
        p.copy(characters = p.characters + ch)
    }

    fun deleteCharacter(id: String) = edit { p ->
        if (p.characters.size <= 1) p else {
            val rest = p.characters.filter { it.id != id }
            val fallback = rest.first().id
            p.copy(
                characters = rest,
                scenes = p.scenes.map { s ->
                    s.copy(
                        characterIds = s.characterIds.filter { it != id },
                        dialogue = s.dialogue.map { d -> if (d.characterId == id) d.copy(characterId = fallback) else d },
                    )
                },
            )
        }
    }

    fun setSubtitle(style: SubtitleStyle) = edit { it.copy(subtitle = style) }
    fun setFormat(format: AspectFormat) = edit { it.copy(format = format) }

    // ---- long-running work --------------------------------------------------------------------

    fun cancelWork() { workJob?.cancel() }

    private fun launchBusy(@StringRes text: Int, block: suspend () -> Unit) {
        if (_state.value.busyText != null) return
        _state.update { it.copy(busyText = text, progress = null, message = null) }
        workJob = viewModelScope.launch {
            try {
                block()
            } catch (e: CancellationException) {
                // cancelled by the user
            } catch (e: Throwable) {
                _state.update { it.copy(message = e.toUiMessage()) }
            } finally {
                _state.update { it.copy(busyText = null, progress = null) }
            }
        }
    }

    private fun setProgress(v: Float) = _state.update { it.copy(progress = v) }

    fun generateImages(all: Boolean) = launchBusy(R.string.busy_images) { generateImagesInternal(all) }
    fun regenerateScene(id: String) = launchBusy(R.string.busy_images) { generateOne(id) }
    fun prepareVoices() = launchBusy(R.string.busy_voice) { ensureVoices() }

    private suspend fun generateImagesInternal(all: Boolean) {
        val p = _state.value.project ?: return
        val todo = p.scenes.filter { s ->
            all || s.imageFile == null || !c.files.imageFile(p.id, s.imageFile).exists()
        }.map { it.id }
        todo.forEachIndexed { i, id ->
            setProgress(i.toFloat() / todo.size)
            generateOne(id)
        }
    }

    private suspend fun generateOne(sceneId: String) {
        val p = _state.value.project ?: return
        val scene = p.scenes.find { it.id == sceneId } ?: return
        val name = c.images.generate(p, scene)
        val bmp = withContext(Dispatchers.IO) { BitmapFactory.decodeFile(c.files.imageFile(p.id, name).path) }
        _state.update { st ->
            val cur = st.project ?: return@update st
            val next = cur.copy(scenes = cur.scenes.map { if (it.id == sceneId) it.copy(imageFile = name) else it })
            st.copy(
                project = next,
                bitmaps = if (bmp != null) st.bitmaps + (sceneId to bmp) else st.bitmaps - sceneId,
                timeline = rebuild(next),
                export = null,
            )
        }
        scheduleSave()
    }

    private suspend fun ensureVoices() {
        val p = _state.value.project ?: return
        val dir = c.files.audioDir(p.id)
        val needed = LinkedHashSet<Pair<String, VoiceProfile>>()
        for (sc in p.scenes) for (dl in sc.dialogue) if (dl.text.isNotBlank()) needed.add(dl.text to voiceOf(p, dl))
        var failed = false
        needed.forEachIndexed { i, (text, voice) ->
            setProgress(i.toFloat() / needed.size)
            val key = c.voice.keyFor(text, voice)
            if (voiceCache[key] == null) {
                try {
                    voiceCache[key] = c.voice.synthesize(text, voice, dir)
                } catch (e: CancellationException) {
                    throw e
                } catch (e: Exception) {
                    failed = true
                }
            }
        }
        _state.update { st -> st.project?.let { st.copy(timeline = rebuild(it)) } ?: st }
        if (failed) _state.update { it.copy(message = UiMessage(R.string.warn_voice_failed, isError = false)) }
    }

    fun export() = launchBusy(R.string.busy_export) {
        generateImagesInternal(false)
        ensureVoices()
        val st = _state.value
        val p = st.project ?: return@launchBusy
        val renderer = FrameRenderer(st.timeline, st.bitmaps, p.subtitle)
        val pcm = withContext(Dispatchers.Default) { AudioMixer.mix(st.timeline) }
        val tmp = File(c.files.cacheDir(), "export_${System.currentTimeMillis()}.mp4")
        try {
            _state.update { it.copy(progress = 0f) }
            c.exporter.export(p.format, st.timeline, renderer, pcm, tmp) { pr -> _state.update { it.copy(progress = pr) } }
            val safe = p.title.replace(Regex("[^\\p{L}\\p{N}_-]+"), "_").trim('_').take(40).ifEmpty { "video" }
            val res = MediaStoreSaver.saveVideo(c.context, tmp, "SketchAI_${safe}_${System.currentTimeMillis() / 1000}.mp4")
            _state.update { it.copy(export = res, message = UiMessage(R.string.msg_export_done, res.location, isError = false)) }
        } finally {
            tmp.delete()
        }
    }
}
