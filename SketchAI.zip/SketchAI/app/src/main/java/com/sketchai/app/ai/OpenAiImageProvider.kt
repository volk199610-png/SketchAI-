package com.sketchai.app.ai

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.util.Base64
import com.sketchai.app.data.AppSettings
import com.sketchai.app.domain.AspectFormat
import com.sketchai.app.network.AiException
import com.sketchai.app.network.ApiClient
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.jsonArray
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import kotlinx.serialization.json.put

/** Works with OpenAI and any server exposing POST /v1/images/generations. */
class OpenAiImageProvider(
    private val api: ApiClient,
    private val json: Json,
    private val settings: () -> AppSettings,
) : ImageGenerationProvider {

    override val name = "OpenAI-compatible"

    override suspend fun generateImage(request: ImageRequest): Bitmap {
        val s = settings()
        if (!s.backendConfigured) throw AiException(AiException.Kind.NOT_CONFIGURED, "Backend URL is empty")

        val body = buildJsonObject {
            put("model", s.imageModel)
            put("prompt", request.prompt + ". Avoid: " + request.negativePrompt)
            put("n", 1)
            put("size", sizeFor(request.format, s.imageModel))
        }.toString()

        val raw = api.postJson(ApiClient.join(s.backendUrl, "images/generations"), body, s.apiKey)
        val item = try {
            json.parseToJsonElement(raw).jsonObject["data"]!!.jsonArray[0].jsonObject
        } catch (e: Exception) {
            throw AiException(AiException.Kind.INVALID_RESPONSE, "No image in response")
        }
        val bytes = when {
            item["b64_json"] != null -> Base64.decode(item["b64_json"]!!.jsonPrimitive.content, Base64.DEFAULT)
            item["url"] != null -> api.getBytes(item["url"]!!.jsonPrimitive.content)
            else -> throw AiException(AiException.Kind.INVALID_RESPONSE, "Neither b64_json nor url")
        }
        return BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
            ?: throw AiException(AiException.Kind.INVALID_RESPONSE, "Cannot decode image")
    }

    private fun sizeFor(f: AspectFormat, model: String): String {
        val gpt = model.contains("gpt-image", ignoreCase = true)
        return when (f) {
            AspectFormat.PORTRAIT -> if (gpt) "1024x1536" else "1024x1792"
            AspectFormat.LANDSCAPE -> if (gpt) "1536x1024" else "1792x1024"
            AspectFormat.SQUARE -> "1024x1024"
        }
    }
}
