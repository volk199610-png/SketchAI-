package com.sketchai.app.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowDownward
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Card
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.sketchai.app.R
import com.sketchai.app.domain.Beat
import com.sketchai.app.domain.Character
import com.sketchai.app.domain.DialogueLine
import com.sketchai.app.domain.Project
import com.sketchai.app.domain.Scene
import com.sketchai.app.presentation.ProjectState
import com.sketchai.app.presentation.ProjectViewModel
import java.util.Locale

@Composable
fun ScriptTab(st: ProjectState, vm: ProjectViewModel) {
    val p = st.project ?: return
    LazyColumn(
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        item { EditField(p.title, vm::setTitle, stringResource(R.string.title), singleLine = true) }
        itemsIndexed(p.scenes, key = { _, s -> s.id }) { i, sc -> SceneCard(i, sc, p, vm) }
        item {
            OutlinedButton(onClick = vm::addScene, modifier = Modifier.fillMaxWidth()) {
                Icon(Icons.Filled.Add, null)
                Text(stringResource(R.string.add_scene), modifier = Modifier.padding(start = 8.dp))
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun SceneCard(index: Int, sc: Scene, p: Project, vm: ProjectViewModel) {
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    stringResource(R.string.scene_n, index + 1) + " · " + sc.beat.label(),
                    fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f),
                )
                IconButton({ vm.moveScene(sc.id, -1) }, enabled = index > 0) { Icon(Icons.Filled.ArrowUpward, null) }
                IconButton({ vm.moveScene(sc.id, 1) }, enabled = index < p.scenes.lastIndex) { Icon(Icons.Filled.ArrowDownward, null) }
                IconButton({ vm.deleteScene(sc.id) }, enabled = p.scenes.size > 1) { Icon(Icons.Filled.Delete, null) }
            }

            ChipRow(Beat.entries, sc.beat, { b -> vm.updateScene(sc.id) { it.copy(beat = b) } }) { it.label() }

            EditField(
                sc.action, { v -> vm.updateScene(sc.id) { it.copy(action = v) } },
                stringResource(R.string.action), resetKey = sc.id, minLines = 2,
            )

            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    stringResource(R.string.duration_s, String.format(Locale.US, "%.1f", sc.durationSec)),
                    modifier = Modifier.weight(1f),
                )
                IconButton({ vm.updateScene(sc.id) { it.copy(durationSec = (it.durationSec - 0.5f).coerceAtLeast(1f)) } }) {
                    Icon(Icons.Filled.Remove, null)
                }
                IconButton({ vm.updateScene(sc.id) { it.copy(durationSec = (it.durationSec + 0.5f).coerceAtMost(20f)) } }) {
                    Icon(Icons.Filled.Add, null)
                }
            }

            Text(stringResource(R.string.in_scene), style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                p.characters.forEach { ch ->
                    val on = ch.id in sc.characterIds
                    FilterChip(
                        selected = on,
                        onClick = {
                            vm.updateScene(sc.id) { s ->
                                s.copy(characterIds = if (on) s.characterIds - ch.id else s.characterIds + ch.id)
                            }
                        },
                        label = { Text(ch.name) },
                    )
                }
            }

            Text(stringResource(R.string.dialogue), style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            sc.dialogue.forEachIndexed { k, dl ->
                Row(verticalAlignment = Alignment.Top, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    SpeakerPicker(p.characters, dl.characterId) { id ->
                        vm.updateScene(sc.id) { s -> s.copy(dialogue = s.dialogue.mapIndexed { j, d -> if (j == k) d.copy(characterId = id) else d }) }
                    }
                    Box(Modifier.weight(1f)) {
                        EditField(
                            dl.text,
                            { v -> vm.updateScene(sc.id) { s -> s.copy(dialogue = s.dialogue.mapIndexed { j, d -> if (j == k) d.copy(text = v) else d }) } },
                            stringResource(R.string.line), resetKey = "${sc.id}#$k#${sc.dialogue.size}",
                        )
                    }
                    IconButton({ vm.updateScene(sc.id) { s -> s.copy(dialogue = s.dialogue.filterIndexed { j, _ -> j != k }) } }) {
                        Icon(Icons.Filled.Close, null)
                    }
                }
            }
            TextButton(onClick = {
                vm.updateScene(sc.id) { s ->
                    val who = s.characterIds.firstOrNull() ?: p.characters.first().id
                    s.copy(dialogue = s.dialogue + DialogueLine(who, ""))
                }
            }) {
                Icon(Icons.Filled.Add, null)
                Text(stringResource(R.string.add_line), modifier = Modifier.padding(start = 8.dp))
            }
        }
    }
}

@Composable
private fun SpeakerPicker(chars: List<Character>, selectedId: String, onPick: (String) -> Unit) {
    var open by remember { mutableStateOf(false) }
    val name = chars.find { it.id == selectedId }?.name ?: "?"
    Box(Modifier.padding(top = 8.dp)) {
        AssistChip(onClick = { open = true }, label = { Text(name.take(10)) })
        DropdownMenu(expanded = open, onDismissRequest = { open = false }) {
            chars.forEach { c ->
                DropdownMenuItem(text = { Text(c.name) }, onClick = { open = false; onPick(c.id) })
            }
        }
    }
}
