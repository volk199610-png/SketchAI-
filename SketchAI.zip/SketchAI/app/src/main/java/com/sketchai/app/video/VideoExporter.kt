package com.sketchai.app.video

import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaFormat
import android.media.MediaMuxer
import com.sketchai.app.audio.AudioMixer
import com.sketchai.app.domain.AspectFormat
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext
import java.io.File
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.coroutines.coroutineContext
import kotlin.math.ceil
import kotlin.math.min

/**
 * Renders every frame of the timeline with [FrameRenderer] onto the input Surface of an H.264 encoder
 * and muxes it together with an AAC track (mixed voices) into an MP4. No native libraries needed.
 */
class VideoExporter {

    private class AacChunk(val data: ByteArray, val ptsUs: Long, val flags: Int)

    suspend fun export(
        format: AspectFormat,
        timeline: Timeline,
        renderer: FrameRenderer,
        pcm: ShortArray?,
        out: File,
        onProgress: (Float) -> Unit,
    ) = withContext(Dispatchers.Default) {
        val w = format.w
        val h = format.h
        val fps = FPS
        val totalFrames = ceil(timeline.totalMs * fps / 1000.0).toInt().coerceAtLeast(1)

        out.parentFile?.mkdirs()
        if (out.exists()) out.delete()

        // Audio first (small), so both tracks can be added to the muxer at the same moment.
        var audioFormat: MediaFormat? = null
        val audioChunks = ArrayList<AacChunk>()
        if (pcm != null && pcm.isNotEmpty()) {
            audioFormat = encodeAac(pcm, audioChunks)
        }

        val vFormat = MediaFormat.createVideoFormat(MediaFormat.MIMETYPE_VIDEO_AVC, w, h).apply {
            setInteger(MediaFormat.KEY_COLOR_FORMAT, MediaCodecInfo.CodecCapabilities.COLOR_FormatSurface)
            setInteger(MediaFormat.KEY_BIT_RATE, if (w * h > 1_500_000) 8_000_000 else 5_000_000)
            setInteger(MediaFormat.KEY_FRAME_RATE, fps)
            setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 1)
        }
        val encoder = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_VIDEO_AVC)
        val muxer = MediaMuxer(out.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
        var muxerStarted = false
        var videoTrack = -1
        var frameIndex = 0L
        val info = MediaCodec.BufferInfo()

        try {
            encoder.configure(vFormat, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
            val surface = encoder.createInputSurface()
            encoder.start()

            fun drain(endOfStream: Boolean) {
                if (endOfStream) encoder.signalEndOfInputStream()
                var idle = 0
                while (true) {
                    val idx = encoder.dequeueOutputBuffer(info, if (endOfStream) 10_000L else 0L)
                    when {
                        idx == MediaCodec.INFO_TRY_AGAIN_LATER -> {
                            if (!endOfStream) return
                            if (++idle > 500) return // 5 s safety net
                        }
                        idx == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> {
                            videoTrack = muxer.addTrack(encoder.outputFormat)
                            val aTrack = audioFormat?.let { muxer.addTrack(it) } ?: -1
                            muxer.start()
                            muxerStarted = true
                            if (aTrack >= 0) {
                                val bi = MediaCodec.BufferInfo()
                                for (c in audioChunks) {
                                    bi.set(0, c.data.size, c.ptsUs, c.flags)
                                    muxer.writeSampleData(aTrack, ByteBuffer.wrap(c.data), bi)
                                }
                            }
                        }
                        idx >= 0 -> {
                            val buf = encoder.getOutputBuffer(idx)
                            if (info.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG != 0) info.size = 0
                            if (buf != null && info.size > 0 && muxerStarted) {
                                // Use our own frame clock; the surface timestamps are wall-clock.
                                info.presentationTimeUs = frameIndex * 1_000_000L / fps
                                frameIndex++
                                buf.position(info.offset)
                                buf.limit(info.offset + info.size)
                                muxer.writeSampleData(videoTrack, buf, info)
                            }
                            val eos = info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0
                            encoder.releaseOutputBuffer(idx, false)
                            if (eos) return
                        }
                    }
                }
            }

            for (i in 0 until totalFrames) {
                coroutineContext.ensureActive()
                val canvas = surface.lockHardwareCanvas()
                try {
                    renderer.draw(canvas, w, h, i * 1000L / fps)
                } finally {
                    surface.unlockCanvasAndPost(canvas)
                }
                drain(false)
                if (i % 5 == 0) onProgress(i.toFloat() / totalFrames)
            }
            drain(true)
            surface.release()
            onProgress(1f)
        } finally {
            runCatching { encoder.stop() }
            runCatching { encoder.release() }
            if (muxerStarted) runCatching { muxer.stop() }
            runCatching { muxer.release() }
        }
        check(muxerStarted && frameIndex > 0) { "Encoder produced no frames" }
    }

    /** Encodes mono 44.1 kHz PCM into AAC-LC packets. Returns the output format for the muxer. */
    private fun encodeAac(pcm: ShortArray, sink: MutableList<AacChunk>): MediaFormat {
        val rate = AudioMixer.RATE
        val fmt = MediaFormat.createAudioFormat(MediaFormat.MIMETYPE_AUDIO_AAC, rate, 1).apply {
            setInteger(MediaFormat.KEY_AAC_PROFILE, MediaCodecInfo.CodecProfileLevel.AACObjectLC)
            setInteger(MediaFormat.KEY_BIT_RATE, 96_000)
            setInteger(MediaFormat.KEY_MAX_INPUT_SIZE, 16384)
        }
        val codec = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_AUDIO_AAC)
        var outFormat: MediaFormat? = null
        try {
            codec.configure(fmt, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
            codec.start()
            val info = MediaCodec.BufferInfo()
            var pos = 0
            var inputDone = false
            var outputDone = false
            fun ptsUs(sample: Int) = sample * 1_000_000L / rate
            while (!outputDone) {
                if (!inputDone) {
                    val ii = codec.dequeueInputBuffer(10_000L)
                    if (ii >= 0) {
                        val ib = codec.getInputBuffer(ii)!!
                        ib.clear()
                        ib.order(ByteOrder.LITTLE_ENDIAN)
                        val n = min(ib.capacity() / 2, pcm.size - pos)
                        if (n <= 0) {
                            codec.queueInputBuffer(ii, 0, 0, ptsUs(pcm.size), MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                            inputDone = true
                        } else {
                            for (k in 0 until n) ib.putShort(pcm[pos + k])
                            codec.queueInputBuffer(ii, 0, n * 2, ptsUs(pos), 0)
                            pos += n
                        }
                    }
                }
                val oi = codec.dequeueOutputBuffer(info, 10_000L)
                when {
                    oi == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> outFormat = codec.outputFormat
                    oi >= 0 -> {
                        val ob = codec.getOutputBuffer(oi)
                        if (ob != null && info.size > 0 && (info.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG) == 0) {
                            val data = ByteArray(info.size)
                            ob.position(info.offset)
                            ob.limit(info.offset + info.size)
                            ob.get(data)
                            sink.add(AacChunk(data, info.presentationTimeUs, info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM.inv()))
                        }
                        if (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) outputDone = true
                        codec.releaseOutputBuffer(oi, false)
                    }
                }
            }
        } finally {
            runCatching { codec.stop() }
            runCatching { codec.release() }
        }
        return outFormat ?: fmt
    }

    companion object {
        const val FPS = 30
    }
}
