package com.sketchai.app.data

import com.sketchai.app.database.ProjectDao
import com.sketchai.app.database.ProjectEntity
import com.sketchai.app.domain.AppJson
import com.sketchai.app.domain.Project
import com.sketchai.app.utils.ProjectFiles
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext
import kotlinx.serialization.decodeFromString
import kotlinx.serialization.encodeToString
import java.io.File

class ProjectRepository(private val dao: ProjectDao, private val files: ProjectFiles) {

    fun observeSummaries(): Flow<List<ProjectEntity>> = dao.observeAll()

    suspend fun load(id: Long): Project? = withContext(Dispatchers.IO) {
        val e = dao.get(id) ?: return@withContext null
        runCatching { AppJson.instance.decodeFromString<Project>(e.json).copy(id = e.id) }.getOrNull()
    }

    /** Insert or update. Returns the project id. */
    suspend fun save(project: Project): Long = withContext(Dispatchers.IO) {
        val thumb = project.scenes.firstNotNullOfOrNull { it.imageFile }
            ?.let { name -> if (project.id != 0L) files.imageFile(project.id, name).takeIf(File::exists)?.path else null }
        val entity = ProjectEntity(
            id = project.id,
            title = project.title,
            createdAt = project.createdAt,
            durationSec = project.totalDurationSec,
            sceneCount = project.scenes.size,
            thumbnailPath = thumb,
            json = AppJson.instance.encodeToString(project.copy(id = 0)),
        )
        dao.upsert(entity).let { rowId -> if (project.id != 0L) project.id else rowId }
    }

    suspend fun rename(id: Long, title: String) {
        val p = load(id) ?: return
        save(p.copy(title = title))
    }

    suspend fun duplicate(id: Long): Long? {
        val p = load(id) ?: return null
        val newId = save(p.copy(id = 0, title = p.title + " (copy)", createdAt = System.currentTimeMillis()))
        withContext(Dispatchers.IO) {
            runCatching { files.dir(id).copyRecursively(files.dir(newId), overwrite = true) }
        }
        save(p.copy(id = newId, title = p.title + " (copy)", createdAt = System.currentTimeMillis()))
        return newId
    }

    suspend fun delete(id: Long) = withContext(Dispatchers.IO) {
        dao.delete(id)
        files.deleteProject(id)
    }
}
