package com.sketchai.app.ui

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.VideoLibrary
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.material3.MaterialTheme
import androidx.compose.foundation.background
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.sketchai.app.R
import com.sketchai.app.di.AppContainer
import com.sketchai.app.presentation.HomeViewModel
import com.sketchai.app.presentation.ProjectViewModel
import com.sketchai.app.presentation.ProjectsViewModel
import com.sketchai.app.presentation.SettingsViewModel

class VmFactory(private val c: AppContainer, private val projectId: Long = 0L) : ViewModelProvider.Factory {
    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T = when (modelClass) {
        HomeViewModel::class.java -> HomeViewModel(c) as T
        ProjectsViewModel::class.java -> ProjectsViewModel(c) as T
        SettingsViewModel::class.java -> SettingsViewModel(c) as T
        ProjectViewModel::class.java -> ProjectViewModel(c, projectId) as T
        else -> throw IllegalArgumentException("Unknown ViewModel ${modelClass.name}")
    }
}

private data class Tab(val route: String, val label: Int, val icon: androidx.compose.ui.graphics.vector.ImageVector)

@Composable
fun SketchRoot(container: AppContainer) {
    val nav = rememberNavController()
    val entry by nav.currentBackStackEntryAsState()
    val route = entry?.destination?.route
    val tabs = listOf(
        Tab("home", R.string.nav_create, Icons.Filled.AutoAwesome),
        Tab("projects", R.string.nav_projects, Icons.Filled.VideoLibrary),
        Tab("settings", R.string.nav_settings, Icons.Filled.Settings),
    )
    val showBar = tabs.any { it.route == route }

    fun goTab(r: String) = nav.navigate(r) {
        popUpTo("home") { saveState = true }
        launchSingleTop = true
        restoreState = true
    }

    Column(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)) {
        NavHost(nav, startDestination = "home", modifier = Modifier.weight(1f)) {
            composable("home") {
                val vm: HomeViewModel = viewModel(factory = VmFactory(container))
                HomeScreen(vm, onOpenProject = { id -> nav.navigate("project/$id?tab=0&export=false") }, onOpenSettings = { goTab("settings") })
            }
            composable("projects") {
                val vm: ProjectsViewModel = viewModel(factory = VmFactory(container))
                ProjectsScreen(vm, onOpen = { id, tab, export -> nav.navigate("project/$id?tab=$tab&export=$export") })
            }
            composable("settings") {
                val vm: SettingsViewModel = viewModel(factory = VmFactory(container))
                SettingsScreen(vm)
            }
            composable(
                "project/{id}?tab={tab}&export={export}",
                arguments = listOf(
                    navArgument("id") { type = NavType.LongType },
                    navArgument("tab") { type = NavType.IntType; defaultValue = 0 },
                    navArgument("export") { type = NavType.BoolType; defaultValue = false },
                ),
            ) { be ->
                val id = be.arguments?.getLong("id") ?: 0L
                val vm: ProjectViewModel = viewModel(key = "project_$id", factory = VmFactory(container, id))
                ProjectScreen(
                    vm,
                    initialTab = be.arguments?.getInt("tab") ?: 0,
                    autoExport = be.arguments?.getBoolean("export") ?: false,
                    onBack = { nav.popBackStack() },
                    onOpenSettings = { goTab("settings") },
                )
            }
        }
        if (showBar) {
            NavigationBar {
                tabs.forEach { t ->
                    NavigationBarItem(
                        selected = route == t.route,
                        onClick = { goTab(t.route) },
                        icon = { Icon(t.icon, null) },
                        label = { Text(stringResource(t.label)) },
                    )
                }
            }
        }
    }
}
