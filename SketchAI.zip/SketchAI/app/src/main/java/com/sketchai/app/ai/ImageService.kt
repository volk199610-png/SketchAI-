package com.sketchai.app.ai

import android.graphics.Bitmap
import com.sketchai.app.data.AppSettings
import com.sketchai.app.data.ImageBackend
import com.sketchai.app.domain.Project
import com.sketchai.app.domain.Scene
import com.sketchai.app.network.AiException
import com.sketchai.app.utils.ProjectFiles
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.FileOutputStream

/** Chooses the active ImageGenerationProvider from settings and stores the result on disk. */
class ImageService(
    private val settings: () -> AppSettings,
    private val files: ProjectFiles,
    private val local: ImageGenerationProvider,
    private val comfy: ImageGenerationProvider,
    private val openAi: ImageGenerationProvider,
) {
    fun provider(): ImageGenerationProvider = when (settings().imageBackend) {
        ImageBackend.LOCAL -> local
        ImageBackend.COMFYUI -> comfy
        ImageBackend.OPENAI -> openAi
    }

    /** Generates the picture for one scene and returns the saved file name (relative to the project dir). */
    suspend fun generate(project: Project, scene: Scene): String {
        val request = ImageRequest(
            prompt = StylePromptBuilder.scenePrompt(scene, project.characters),
            negativePrompt = StylePromptBuilder.NEGATIVE,
            format = project.format,
            seed = (scene.id.hashCode().toLong() and 0x7fffffffL),
            scene = scene,
            characters = project.characters,
        )
        val bitmap = provider().generateImage(request)
        return withContext(Dispatchers.IO) {
            val name = "img_${scene.id.take(8)}_${System.currentTimeMillis()}.png"
            val out = files.imageFile(project.id, name)
            try {
                FileOutputStream(out).use { bitmap.compress(Bitmap.CompressFormat.PNG, 100, it) }
            } catch (e: Exception) {
                throw AiException(AiException.Kind.GENERATION_FAILED, e.message.orEmpty())
            }
            scene.imageFile?.let { old -> files.imageFile(project.id, old).delete() }
            name
        }
    }
}
