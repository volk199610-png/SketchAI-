package com.sketchai.app.data

import android.content.Context
import android.content.SharedPreferences
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import com.sketchai.app.domain.AspectFormat
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

/**
 * Settings storage. The API key goes to EncryptedSharedPreferences (Android Keystore backed).
 * If the keystore is not available on the device, the key is kept only in memory (never in plain text).
 */
class SettingsRepository(context: Context) {

    private val prefs: SharedPreferences = context.getSharedPreferences("sketchai_settings", Context.MODE_PRIVATE)

    private val secure: SharedPreferences? = try {
        val key = MasterKey.Builder(context).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build()
        EncryptedSharedPreferences.create(
            context, "sketchai_secure", key,
            EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
            EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM,
        )
    } catch (e: Exception) {
        null
    }

    private var memoryKey: String = ""

    private val _state = MutableStateFlow(load())
    val state: StateFlow<AppSettings> = _state

    fun update(transform: (AppSettings) -> AppSettings) {
        val next = transform(_state.value)
        _state.value = next
        persist(next)
    }

    private fun load(): AppSettings {
        val d = AppSettings()
        return AppSettings(
            backendUrl = prefs.getString("backendUrl", d.backendUrl).orEmpty(),
            apiKey = readKey(),
            llmModel = prefs.getString("llmModel", d.llmModel).orEmpty(),
            imageModel = prefs.getString("imageModel", d.imageModel).orEmpty(),
            ttsModel = prefs.getString("ttsModel", d.ttsModel).orEmpty(),
            comfyUrl = prefs.getString("comfyUrl", d.comfyUrl).orEmpty(),
            comfyCheckpoint = prefs.getString("comfyCheckpoint", d.comfyCheckpoint).orEmpty(),
            comfyWorkflow = prefs.getString("comfyWorkflow", d.comfyWorkflow).orEmpty(),
            imageBackend = enumOr(prefs.getString("imageBackend", null), d.imageBackend),
            remoteTts = prefs.getBoolean("remoteTts", d.remoteTts),
            defaultDuration = prefs.getInt("defaultDuration", d.defaultDuration),
            defaultFormat = enumOr(prefs.getString("defaultFormat", null), d.defaultFormat),
            defaultVoice = prefs.getInt("defaultVoice", d.defaultVoice),
            defaultHumor = prefs.getInt("defaultHumor", d.defaultHumor),
            themeMode = enumOr(prefs.getString("themeMode", null), d.themeMode),
            language = prefs.getString("language", d.language).orEmpty().ifBlank { d.language },
        )
    }

    private fun persist(s: AppSettings) {
        prefs.edit()
            .putString("backendUrl", s.backendUrl)
            .putString("llmModel", s.llmModel)
            .putString("imageModel", s.imageModel)
            .putString("ttsModel", s.ttsModel)
            .putString("comfyUrl", s.comfyUrl)
            .putString("comfyCheckpoint", s.comfyCheckpoint)
            .putString("comfyWorkflow", s.comfyWorkflow)
            .putString("imageBackend", s.imageBackend.name)
            .putBoolean("remoteTts", s.remoteTts)
            .putInt("defaultDuration", s.defaultDuration)
            .putString("defaultFormat", s.defaultFormat.name)
            .putInt("defaultVoice", s.defaultVoice)
            .putInt("defaultHumor", s.defaultHumor)
            .putString("themeMode", s.themeMode.name)
            .putString("language", s.language)
            .apply()
        writeKey(s.apiKey)
    }

    private fun readKey(): String = secure?.getString("apiKey", "").orEmpty().ifEmpty { memoryKey }

    private fun writeKey(key: String) {
        memoryKey = key
        secure?.edit()?.putString("apiKey", key)?.apply()
    }

    private inline fun <reified E : Enum<E>> enumOr(name: String?, default: E): E =
        runCatching { enumValueOf<E>(name.orEmpty()) }.getOrDefault(default)
}
