package com.sketchai.app.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.sketchai.app.R
import com.sketchai.app.data.ImageBackend
import com.sketchai.app.data.ThemeMode
import com.sketchai.app.domain.AspectFormat
import com.sketchai.app.domain.VoicePreset
import com.sketchai.app.presentation.Conn
import com.sketchai.app.presentation.ConnState
import com.sketchai.app.presentation.SettingsViewModel
import kotlin.math.roundToInt

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(vm: SettingsViewModel) {
    val s by vm.settings.collectAsStateWithLifecycle()
    val backend by vm.backend.collectAsStateWithLifecycle()
    val comfy by vm.comfy.collectAsStateWithLifecycle()
    var showKey by remember { mutableStateOf(false) }

    Scaffold(
        topBar = { TopAppBar(title = { Text(stringResource(R.string.nav_settings), fontWeight = FontWeight.Bold) }) },
        contentWindowInsets = WindowInsets(0.dp, 0.dp, 0.dp, 0.dp),
    ) { pad ->
        Column(
            Modifier.padding(pad).fillMaxSize().imePadding().verticalScroll(rememberScrollState()).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            SectionTitle(stringResource(R.string.sec_ai_backend))
            EditField(s.backendUrl, { v -> vm.update { it.copy(backendUrl = v) } }, stringResource(R.string.backend_url),
                placeholder = "https://api.openai.com/v1", singleLine = true)
            OutlinedTextField(
                value = s.apiKey, onValueChange = { v -> vm.update { it.copy(apiKey = v) } },
                label = { Text(stringResource(R.string.api_key)) }, singleLine = true,
                visualTransformation = if (showKey) VisualTransformation.None else PasswordVisualTransformation(),
                trailingIcon = {
                    IconButton({ showKey = !showKey }) { Icon(if (showKey) Icons.Filled.VisibilityOff else Icons.Filled.Visibility, null) }
                },
                modifier = Modifier.fillMaxWidth(),
            )
            Text(stringResource(R.string.api_key_note), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            EditField(s.llmModel, { v -> vm.update { it.copy(llmModel = v) } }, stringResource(R.string.llm_model), singleLine = true)
            EditField(s.imageModel, { v -> vm.update { it.copy(imageModel = v) } }, stringResource(R.string.image_model), singleLine = true)
            EditField(s.ttsModel, { v -> vm.update { it.copy(ttsModel = v) } }, stringResource(R.string.tts_model), singleLine = true)
            ConnRow(backend, onTest = vm::testBackend)

            HorizontalDivider()
            SectionTitle(stringResource(R.string.sec_comfy))
            EditField(s.comfyUrl, { v -> vm.update { it.copy(comfyUrl = v) } }, stringResource(R.string.comfy_url),
                placeholder = "http://192.168.1.10:8188", singleLine = true)
            EditField(s.comfyCheckpoint, { v -> vm.update { it.copy(comfyCheckpoint = v) } }, stringResource(R.string.comfy_checkpoint), singleLine = true)
            EditField(s.comfyWorkflow, { v -> vm.update { it.copy(comfyWorkflow = v) } }, stringResource(R.string.comfy_workflow), minLines = 3)
            ConnRow(comfy, onTest = vm::testComfy)

            HorizontalDivider()
            SectionTitle(stringResource(R.string.image_backend))
            ChipRow(ImageBackend.entries, s.imageBackend, { b -> vm.update { it.copy(imageBackend = b) } }) { it.label() }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(stringResource(R.string.remote_tts), Modifier.weight(1f))
                Switch(checked = s.remoteTts, onCheckedChange = { v -> vm.update { it.copy(remoteTts = v) } })
            }

            HorizontalDivider()
            SectionTitle(stringResource(R.string.sec_defaults))
            Text(stringResource(R.string.default_duration))
            ChipRow(listOf(5, 10, 15, 20, 30), s.defaultDuration, { d -> vm.update { it.copy(defaultDuration = d) } }) {
                stringResource(R.string.duration_sec, it)
            }
            Text(stringResource(R.string.default_format))
            ChipRow(AspectFormat.entries, s.defaultFormat, { f -> vm.update { it.copy(defaultFormat = f) } }) { it.label }
            Text(stringResource(R.string.default_voice))
            ChipRow(VoicePreset.entries, VoicePreset.entries[s.defaultVoice.coerceIn(0, 3)], { v -> vm.update { it.copy(defaultVoice = v.ordinal) } }) { it.label() }
            Text(stringResource(R.string.default_humor, s.defaultHumor))
            Slider(value = s.defaultHumor.toFloat(), onValueChange = { v -> vm.update { it.copy(defaultHumor = v.roundToInt()) } }, valueRange = 0f..100f)

            HorizontalDivider()
            SectionTitle(stringResource(R.string.sec_appearance))
            Text(stringResource(R.string.dark_mode))
            ChipRow(ThemeMode.entries, s.themeMode, { m -> vm.update { it.copy(themeMode = m) } }) { it.label() }
            Text(stringResource(R.string.language))
            ChipRow(listOf("ru", "en", "kk"), s.language, { l -> vm.update { it.copy(language = l) } }) { languageName(it) }
        }
    }
}

@Composable
private fun ConnRow(state: ConnState, onTest: () -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        OutlinedButton(onClick = onTest, enabled = state.state != Conn.TESTING) { Text(stringResource(R.string.test_connection)) }
        val text = when (state.state) {
            Conn.UNKNOWN -> stringResource(R.string.conn_unknown)
            Conn.TESTING -> stringResource(R.string.conn_testing)
            Conn.OK -> stringResource(R.string.conn_ok)
            Conn.FAILED -> stringResource(R.string.conn_failed) + (state.detail?.let { " ($it)" } ?: "")
        }
        Text(text, style = MaterialTheme.typography.bodySmall,
            color = if (state.state == Conn.FAILED) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurfaceVariant)
    }
}
