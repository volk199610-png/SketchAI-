package com.sketchai.app.ui

import androidx.compose.runtime.Composable
import androidx.compose.ui.res.stringResource
import com.sketchai.app.R
import com.sketchai.app.data.ImageBackend
import com.sketchai.app.data.ThemeMode
import com.sketchai.app.domain.Beat
import com.sketchai.app.domain.Genre
import com.sketchai.app.domain.SubtitleAnim
import com.sketchai.app.domain.SubtitleFont
import com.sketchai.app.domain.SubtitleLook
import com.sketchai.app.domain.SubtitlePosition
import com.sketchai.app.domain.VoicePreset

@Composable
fun Genre.label(): String = stringResource(
    when (this) {
        Genre.BLACK_HUMOR -> R.string.genre_black
        Genre.ABSURD -> R.string.genre_absurd
        Genre.SARCASM -> R.string.genre_sarcasm
        Genre.REGULAR -> R.string.genre_regular
    },
)

@Composable
fun Beat.label(): String = stringResource(
    when (this) {
        Beat.SETUP -> R.string.beat_setup
        Beat.BUILD_UP -> R.string.beat_buildup
        Beat.PAUSE -> R.string.beat_pause
        Beat.PUNCHLINE -> R.string.beat_punchline
        Beat.ENDING -> R.string.beat_ending
    },
)

@Composable
fun VoicePreset.label(): String = stringResource(
    when (this) {
        VoicePreset.MALE_CALM -> R.string.voice_male_calm
        VoicePreset.MALE_NERVOUS -> R.string.voice_male_nervous
        VoicePreset.FEMALE_CALM -> R.string.voice_female_calm
        VoicePreset.FEMALE_BRIGHT -> R.string.voice_female_bright
    },
)

@Composable
fun SubtitleFont.label(): String = stringResource(
    when (this) {
        SubtitleFont.SANS -> R.string.font_sans
        SubtitleFont.SERIF -> R.string.font_serif
        SubtitleFont.MONO -> R.string.font_mono
        SubtitleFont.HAND -> R.string.font_hand
    },
)

@Composable
fun SubtitlePosition.label(): String = stringResource(
    when (this) {
        SubtitlePosition.TOP -> R.string.pos_top
        SubtitlePosition.CENTER -> R.string.pos_center
        SubtitlePosition.BOTTOM -> R.string.pos_bottom
    },
)

@Composable
fun SubtitleLook.label(): String = stringResource(
    when (this) {
        SubtitleLook.BLACK_ON_WHITE -> R.string.look_black_on_white
        SubtitleLook.WHITE_STROKE -> R.string.look_white_stroke
    },
)

@Composable
fun SubtitleAnim.label(): String = stringResource(
    when (this) {
        SubtitleAnim.NONE -> R.string.anim_none
        SubtitleAnim.FADE -> R.string.anim_fade
        SubtitleAnim.TYPEWRITER -> R.string.anim_typewriter
    },
)

@Composable
fun ImageBackend.label(): String = stringResource(
    when (this) {
        ImageBackend.LOCAL -> R.string.backend_local
        ImageBackend.COMFYUI -> R.string.backend_comfy
        ImageBackend.OPENAI -> R.string.backend_openai
    },
)

@Composable
fun ThemeMode.label(): String = stringResource(
    when (this) {
        ThemeMode.SYSTEM -> R.string.theme_system
        ThemeMode.LIGHT -> R.string.theme_light
        ThemeMode.DARK -> R.string.theme_dark
    },
)

fun languageName(tag: String): String = when (tag) {
    "ru" -> "Русский"
    "kk" -> "Қазақша"
    else -> "English"
}
