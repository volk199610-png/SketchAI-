package com.sketchai.app.ai

import com.sketchai.app.data.AppSettings
import com.sketchai.app.domain.Beat
import com.sketchai.app.domain.Character
import com.sketchai.app.domain.ComedyRequest
import com.sketchai.app.domain.ComedyResult
import com.sketchai.app.domain.DialogueLine
import com.sketchai.app.domain.Genre
import com.sketchai.app.domain.Scene
import com.sketchai.app.network.AiException
import com.sketchai.app.network.ApiClient
import kotlinx.coroutines.CancellationException
import kotlinx.serialization.Serializable
import kotlinx.serialization.decodeFromString
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.buildJsonArray
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.add
import kotlinx.serialization.json.jsonArray
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import kotlinx.serialization.json.put
import kotlin.math.max

interface ScriptProvider {
    suspend fun write(req: ComedyRequest): ComedyResult
}

/**
 * Turns an idea into a structured script (setup -> build-up -> pause -> punchline -> ending).
 * Uses the configured LLM backend, and falls back to an offline template when it is missing or fails.
 */
class ComedyEngine(
    private val settings: () -> AppSettings,
    private val llm: ScriptProvider,
    private val offline: ScriptProvider,
) {
    suspend fun generate(req: ComedyRequest): ComedyResult {
        if (!settings().backendConfigured) return offline.write(req)
        return try {
            llm.write(req)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            offline.write(req).copy(usedFallback = true)
        }
    }
}

// ---------------------------------------------------------------------------------------------

object ComedyPrompts {
    private fun genreText(g: Genre) = when (g) {
        Genre.BLACK_HUMOR -> "black humor: death, bureaucracy, existential dread, deadpan delivery, dark twist"
        Genre.ABSURD -> "absurd humor: logical but ridiculous escalation, surreal twist"
        Genre.SARCASM -> "sarcasm: dry, ironic, understated replies"
        Genre.REGULAR -> "light everyday humor with a clever twist"
    }

    fun system(req: ComedyRequest): String = """
You write very short comedy sketches for black-and-white stick-figure animations.
Genre: ${genreText(req.genre)}.
Humor intensity: ${req.humorLevel}/100 (0 = very mild, 100 = very dark and edgy). Never target protected groups, never involve minors in harm, no real people.
Principle: short setup -> unexpected development -> punchline. No long dialogue: every line is at most 12 words.
Total duration about ${req.durationSec} seconds. Use ${sceneCountFor(req.durationSec)} scenes, each 3-8 seconds.
Exactly ${req.characterCount} character(s).
Allowed beats (use in this order, skip some if needed): SETUP, BUILD_UP, PAUSE, PUNCHLINE, ENDING. The last spoken line is the punchline and goes inside the dialogue of the PUNCHLINE scene.
Write dialogue in the same language as the user's idea. Write all other fields in English.
Character visuals must be simple enough for black-and-white line art.
Return ONLY a JSON object, no markdown, with this shape:
{"title":"...","characters":[{"name":"...","gender":"male|female","age":"...","hair":"...","face":"...","body":"...","clothes":"...","accessories":"...","personality":"..."}],
"scenes":[{"beat":"SETUP","duration":5,"characters":["name"],"action":"what is visible","dialogue":[{"speaker":"name","text":"..."}]}]}
""".trimIndent()

    fun sceneCountFor(durationSec: Int): Int = (durationSec / 5).coerceIn(3, 6)
}

@Serializable
private data class LineDto(val speaker: String = "", val text: String = "")

@Serializable
private data class CharDto(
    val name: String = "", val gender: String = "male", val age: String = "", val hair: String = "",
    val face: String = "", val body: String = "", val clothes: String = "", val accessories: String = "",
    val personality: String = "",
)

@Serializable
private data class SceneDto(
    val beat: String = "", val duration: Float = 5f, val characters: List<String> = emptyList(),
    val action: String = "", val dialogue: List<LineDto> = emptyList(),
)

@Serializable
private data class ScriptDto(
    val title: String = "", val characters: List<CharDto> = emptyList(), val scenes: List<SceneDto> = emptyList(),
)

class LlmScriptProvider(
    private val api: ApiClient,
    private val json: Json,
    private val settings: () -> AppSettings,
) : ScriptProvider {

    override suspend fun write(req: ComedyRequest): ComedyResult {
        val s = settings()
        val body = buildJsonObject {
            put("model", s.llmModel)
            put("temperature", 0.6 + req.humorLevel / 100.0 * 0.5)
            put("response_format", buildJsonObject { put("type", "json_object") })
            put("messages", buildJsonArray {
                add(buildJsonObject { put("role", "system"); put("content", ComedyPrompts.system(req)) })
                add(buildJsonObject { put("role", "user"); put("content", req.idea) })
            })
        }.toString()

        val raw = api.postJson(ApiClient.join(s.backendUrl, "chat/completions"), body, s.apiKey)
        val content = try {
            json.parseToJsonElement(raw).jsonObject["choices"]!!.jsonArray[0].jsonObject["message"]!!
                .jsonObject["content"]!!.jsonPrimitive.content
        } catch (e: Exception) {
            throw AiException(AiException.Kind.INVALID_RESPONSE, "Unexpected chat response")
        }
        return parse(content, req)
    }

    private fun parse(content: String, req: ComedyRequest): ComedyResult {
        val start = content.indexOf('{')
        val end = content.lastIndexOf('}')
        if (start < 0 || end <= start) throw AiException(AiException.Kind.INVALID_RESPONSE, "No JSON in answer")
        val dto = try {
            json.decodeFromString<ScriptDto>(content.substring(start, end + 1))
        } catch (e: Exception) {
            throw AiException(AiException.Kind.INVALID_RESPONSE, e.message.orEmpty())
        }
        if (dto.scenes.isEmpty()) throw AiException(AiException.Kind.INVALID_RESPONSE, "Script has no scenes")

        val chars = dto.characters.take(req.characterCount).mapIndexed { i, c ->
            val name = c.name.ifBlank { "Character ${i + 1}" }
            val preset = CharacterFactory.voiceFor(c.gender, c.personality, i, req.defaultVoice)
            val d = CharacterFactory.default(i, name, req.defaultVoice)
            Character(
                id = CharacterFactory.idFor(name, i), name = name,
                gender = c.gender.ifBlank { d.gender }, age = c.age.ifBlank { d.age },
                hair = c.hair.ifBlank { d.hair }, face = c.face.ifBlank { d.face },
                body = c.body.ifBlank { d.body }, clothes = c.clothes.ifBlank { d.clothes },
                accessories = c.accessories, personality = c.personality.ifBlank { d.personality },
                voice = preset.toProfile(),
            )
        }.ifEmpty { listOf(CharacterFactory.default(0, "Character 1", req.defaultVoice)) }

        fun idOf(name: String): String =
            chars.find { it.name.equals(name.trim(), ignoreCase = true) }?.id ?: chars.first().id

        var scenes = dto.scenes.take(8).mapIndexed { i, s ->
            val beat = Beat.entries.firstOrNull { it.name.equals(s.beat.replace('-', '_').trim(), ignoreCase = true) }
                ?: when (i) { 0 -> Beat.SETUP; dto.scenes.size - 1 -> Beat.PUNCHLINE; else -> Beat.BUILD_UP }
            val ids = s.characters.map { idOf(it) }.distinct().ifEmpty { listOf(chars.first().id) }
            Scene(
                beat = beat, durationSec = s.duration.coerceIn(2f, 10f), characterIds = ids, action = s.action,
                dialogue = s.dialogue.filter { it.text.isNotBlank() }.map { DialogueLine(idOf(it.speaker), it.text.trim()) },
            )
        }
        // Normalise the total duration to what the user asked for.
        val sum = scenes.sumOf { it.durationSec.toDouble() }.toFloat()
        if (sum > 0f) {
            val k = req.durationSec / sum
            scenes = scenes.map { it.copy(durationSec = (it.durationSec * k).coerceIn(1.5f, 12f)) }
        }
        return ComedyResult(dto.title.ifBlank { req.idea.take(40) }, chars, scenes)
    }
}

/**
 * Offline fallback. It cannot invent jokes, but it splits the user's own idea into
 * setup / build-up / pause / punchline / ending so the rest of the pipeline works without any backend.
 */
class OfflineScriptProvider : ScriptProvider {

    override suspend fun write(req: ComedyRequest): ComedyResult {
        val chars = (0 until req.characterCount.coerceIn(1, 4)).map {
            CharacterFactory.default(it, "Character ${it + 1}", req.defaultVoice)
        }
        val sentences = req.idea.split(Regex("(?<=[.!?…])\\s+|\\n+")).map { it.trim() }.filter { it.isNotEmpty() }
        val beats = beatsFor(ComedyPrompts.sceneCountFor(req.durationSec))
        val each = req.durationSec.toFloat() / beats.size

        // Distribute sentences: first -> SETUP, last -> PUNCHLINE, the rest -> BUILD_UP.
        val spoken = Array(beats.size) { mutableListOf<String>() }
        val setupIdx = beats.indexOf(Beat.SETUP)
        val buildIdx = beats.indexOf(Beat.BUILD_UP)
        val punchIdx = beats.indexOf(Beat.PUNCHLINE)
        sentences.forEachIndexed { i, s ->
            val target = when {
                i == 0 -> setupIdx
                i == sentences.lastIndex -> punchIdx
                else -> buildIdx
            }
            spoken[target].add(s)
        }
        var speaker = 0
        val scenes = beats.mapIndexed { i, beat ->
            val lines = spoken[i].map { text ->
                DialogueLine(chars[speaker++ % chars.size].id, text)
            }
            val action = when (beat) {
                Beat.SETUP -> "Characters stand in a simple place and start talking"
                Beat.BUILD_UP -> "The conversation develops, one character gestures"
                Beat.PAUSE -> "Silence, characters look at each other"
                Beat.PUNCHLINE -> "Surprising reaction, one character is shocked"
                Beat.ENDING -> "Final quiet image after the joke"
            }
            Scene(
                beat = beat, durationSec = max(2f, each), characterIds = chars.map { it.id },
                action = action, dialogue = lines,
            )
        }
        return ComedyResult(req.idea.take(40), chars, scenes)
    }

    private fun beatsFor(count: Int): List<Beat> = when (count) {
        3 -> listOf(Beat.SETUP, Beat.BUILD_UP, Beat.PUNCHLINE)
        4 -> listOf(Beat.SETUP, Beat.BUILD_UP, Beat.PAUSE, Beat.PUNCHLINE)
        5 -> listOf(Beat.SETUP, Beat.BUILD_UP, Beat.PAUSE, Beat.PUNCHLINE, Beat.ENDING)
        else -> listOf(Beat.SETUP, Beat.BUILD_UP, Beat.BUILD_UP, Beat.PAUSE, Beat.PUNCHLINE, Beat.ENDING)
    }
}
