package com.sketchai.app.ui

import android.widget.Toast
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.sketchai.app.R
import com.sketchai.app.domain.AspectFormat
import com.sketchai.app.domain.Genre
import com.sketchai.app.presentation.HomeViewModel
import kotlin.math.roundToInt

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(vm: HomeViewModel, onOpenProject: (Long) -> Unit, onOpenSettings: () -> Unit) {
    val s by vm.state.collectAsStateWithLifecycle()
    val settings by vm.settings.collectAsStateWithLifecycle()
    val ctx = LocalContext.current

    val msg = s.message
    val warnText = if (msg != null && !msg.isError) stringResource(msg.resId) else null
    LaunchedEffect(warnText) {
        if (warnText != null) {
            Toast.makeText(ctx, warnText, Toast.LENGTH_LONG).show()
            vm.dismissMessage()
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(title = {
                Text("SKETCH AI", fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Black)
            })
        },
        contentWindowInsets = WindowInsets(0.dp, 0.dp, 0.dp, 0.dp),
    ) { pad ->
        Column(
            Modifier.padding(pad).fillMaxSize().imePadding().verticalScroll(rememberScrollState()).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
        ) {
            if (!settings.backendConfigured) {
                Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
                    Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text(stringResource(R.string.backend_not_configured), fontWeight = FontWeight.Bold)
                        Text(stringResource(R.string.backend_offline_note), style = MaterialTheme.typography.bodySmall)
                        OutlinedButton(onClick = onOpenSettings) { Text(stringResource(R.string.open_ai_settings)) }
                    }
                }
            }

            OutlinedTextField(
                value = s.idea,
                onValueChange = { v -> vm.edit { it.copy(idea = v) } },
                label = { Text(stringResource(R.string.idea_label)) },
                placeholder = { Text(stringResource(R.string.idea_hint)) },
                minLines = 4,
                modifier = Modifier.fillMaxWidth(),
            )

            SectionTitle(stringResource(R.string.genre))
            ChipRow(Genre.entries, s.genre, { g -> vm.edit { it.copy(genre = g) } }) { it.label() }

            SectionTitle(stringResource(R.string.humor_level, s.humor))
            Slider(
                value = s.humor.toFloat(), onValueChange = { v -> vm.edit { it.copy(humor = v.roundToInt()) } },
                valueRange = 0f..100f,
            )

            SectionTitle(stringResource(R.string.duration))
            ChipRow(listOf(5, 10, 15, 20, 30), s.duration, { d -> vm.edit { it.copy(duration = d) } }) {
                stringResource(R.string.duration_sec, it)
            }

            SectionTitle(stringResource(R.string.characters_count, s.characters))
            Slider(
                value = s.characters.toFloat(), onValueChange = { v -> vm.edit { it.copy(characters = v.roundToInt()) } },
                valueRange = 1f..4f, steps = 2,
            )

            SectionTitle(stringResource(R.string.format))
            ChipRow(AspectFormat.entries, s.format, { f -> vm.edit { it.copy(format = f) } }) { it.label }

            SectionTitle(stringResource(R.string.style))
            Surface(shape = MaterialTheme.shapes.medium, border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)) {
                Text(
                    stringResource(R.string.style_bw), modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp),
                    fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold,
                )
            }

            val m = s.message
            if (m != null && m.isError) {
                MessageCard(m, onDismiss = vm::dismissMessage, onOpenSettings = onOpenSettings)
            }

            Button(
                onClick = { vm.generate(onOpenProject) },
                enabled = s.idea.isNotBlank() && !s.busy,
                modifier = Modifier.fillMaxWidth().height(56.dp),
            ) {
                if (s.busy) {
                    CircularProgressIndicator(Modifier.size(22.dp), strokeWidth = 2.dp, color = MaterialTheme.colorScheme.onPrimary)
                } else {
                    Text(stringResource(R.string.generate), fontWeight = FontWeight.Black)
                }
            }
        }
    }
}
