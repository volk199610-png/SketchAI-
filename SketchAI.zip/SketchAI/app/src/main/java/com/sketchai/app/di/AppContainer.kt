package com.sketchai.app.di

import android.content.Context
import androidx.room.Room
import com.sketchai.app.ai.ComedyEngine
import com.sketchai.app.ai.ComfyUiImageProvider
import com.sketchai.app.ai.ImageService
import com.sketchai.app.ai.LlmScriptProvider
import com.sketchai.app.ai.LocalSketchImageProvider
import com.sketchai.app.ai.OfflineScriptProvider
import com.sketchai.app.ai.OpenAiImageProvider
import com.sketchai.app.audio.AndroidTtsProvider
import com.sketchai.app.audio.OpenAiTtsProvider
import com.sketchai.app.audio.VoiceService
import com.sketchai.app.data.ProjectRepository
import com.sketchai.app.data.SettingsRepository
import com.sketchai.app.database.AppDatabase
import com.sketchai.app.domain.AppJson
import com.sketchai.app.network.ApiClient
import com.sketchai.app.utils.ProjectFiles
import com.sketchai.app.video.VideoExporter
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob

/** Manual dependency injection: one place that wires every implementation to its interface. */
class AppContainer(val context: Context) {
    val appScope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    val json = AppJson.instance

    val settings = SettingsRepository(context)
    private val currentSettings = { settings.state.value }

    val files = ProjectFiles(context)
    private val database = Room.databaseBuilder(context, AppDatabase::class.java, "sketchai.db").build()
    val projects = ProjectRepository(database.projectDao(), files)

    val api = ApiClient()

    val comedy = ComedyEngine(
        settings = currentSettings,
        llm = LlmScriptProvider(api, json, currentSettings),
        offline = OfflineScriptProvider(),
    )

    val images = ImageService(
        settings = currentSettings,
        files = files,
        local = LocalSketchImageProvider(),
        comfy = ComfyUiImageProvider(api, json, currentSettings),
        openAi = OpenAiImageProvider(api, json, currentSettings),
    )

    val voice = VoiceService(
        settings = currentSettings,
        local = AndroidTtsProvider(context, currentSettings),
        remote = OpenAiTtsProvider(api, currentSettings),
    )

    val exporter = VideoExporter()
}
