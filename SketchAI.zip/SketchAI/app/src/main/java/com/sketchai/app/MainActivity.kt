package com.sketchai.app

import android.os.Bundle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.core.os.LocaleListCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.sketchai.app.ui.SketchRoot
import com.sketchai.app.ui.SketchTheme

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        val container = (application as SketchApp).container
        setContent {
            val settings by container.settings.state.collectAsStateWithLifecycle()
            LaunchedEffect(settings.language) { applyLanguage(settings.language) }
            SketchTheme(settings.themeMode) { SketchRoot(container) }
        }
    }

    private fun applyLanguage(tag: String) {
        val target = LocaleListCompat.forLanguageTags(tag)
        if (AppCompatDelegate.getApplicationLocales().toLanguageTags() != target.toLanguageTags()) {
            AppCompatDelegate.setApplicationLocales(target)
        }
    }
}
