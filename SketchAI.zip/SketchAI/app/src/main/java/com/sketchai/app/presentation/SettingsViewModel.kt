package com.sketchai.app.presentation

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.sketchai.app.data.AppSettings
import com.sketchai.app.di.AppContainer
import com.sketchai.app.network.AiException
import com.sketchai.app.network.ApiClient
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

enum class Conn { UNKNOWN, TESTING, OK, FAILED }
data class ConnState(val state: Conn = Conn.UNKNOWN, val detail: String? = null)

class SettingsViewModel(private val c: AppContainer) : ViewModel() {
    val settings: StateFlow<AppSettings> = c.settings.state

    private val _backend = MutableStateFlow(ConnState())
    val backend = _backend.asStateFlow()
    private val _comfy = MutableStateFlow(ConnState())
    val comfy = _comfy.asStateFlow()

    fun update(f: (AppSettings) -> AppSettings) = c.settings.update(f)

    fun testBackend() = test(_backend) {
        val s = c.settings.state.value
        if (!s.backendConfigured) throw AiException(AiException.Kind.NOT_CONFIGURED, "")
        c.api.getString(ApiClient.join(s.backendUrl, "models"), s.apiKey)
    }

    fun testComfy() = test(_comfy) {
        val s = c.settings.state.value
        if (!s.comfyConfigured) throw AiException(AiException.Kind.NOT_CONFIGURED, "")
        c.api.getString(ApiClient.join(s.comfyUrl, "system_stats"))
    }

    private fun test(target: MutableStateFlow<ConnState>, block: suspend () -> Unit) {
        target.value = ConnState(Conn.TESTING)
        viewModelScope.launch {
            target.value = try {
                block()
                ConnState(Conn.OK)
            } catch (e: kotlinx.coroutines.CancellationException) {
                throw e
            } catch (e: Exception) {
                ConnState(Conn.FAILED, (e as? AiException)?.kind?.name ?: e.javaClass.simpleName)
            }
        }
    }
}
