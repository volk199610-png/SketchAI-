package com.sketchai.app.ai

import android.graphics.Bitmap
import com.sketchai.app.domain.AspectFormat
import com.sketchai.app.domain.Character
import com.sketchai.app.domain.Scene

data class ImageRequest(
    val prompt: String,
    val negativePrompt: String,
    val format: AspectFormat,
    val seed: Long,
    val scene: Scene,
    val characters: List<Character>,
)

/** Swap-in point for any image backend. Implementations must throw AiException on failure. */
interface ImageGenerationProvider {
    val name: String
    suspend fun generateImage(request: ImageRequest): Bitmap
}
