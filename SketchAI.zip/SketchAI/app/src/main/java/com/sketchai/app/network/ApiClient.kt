package com.sketchai.app.network

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import okhttp3.Response
import java.io.IOException
import java.net.SocketTimeoutException
import java.util.concurrent.TimeUnit

/** Thin wrapper over OkHttp that converts every failure into an [AiException] with a meaningful kind. */
class ApiClient(base: OkHttpClient? = null) {

    private val client: OkHttpClient = (base ?: OkHttpClient()).newBuilder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(180, TimeUnit.SECONDS)
        .writeTimeout(60, TimeUnit.SECONDS)
        .build()

    suspend fun <T> call(request: Request, parse: (Response) -> T): T = withContext(Dispatchers.IO) {
        try {
            client.newCall(request).execute().use { resp ->
                if (!resp.isSuccessful) {
                    val body = runCatching { resp.body?.string() }.getOrNull()?.take(300).orEmpty()
                    throw httpError(resp.code, body)
                }
                parse(resp)
            }
        } catch (e: AiException) {
            throw e
        } catch (e: SocketTimeoutException) {
            throw AiException(AiException.Kind.TIMEOUT, e.message.orEmpty())
        } catch (e: IOException) {
            throw AiException(AiException.Kind.CONNECTION, e.message.orEmpty())
        } catch (e: IllegalArgumentException) {
            throw AiException(AiException.Kind.INVALID_RESPONSE, e.message.orEmpty())
        } catch (e: IllegalStateException) {
            throw AiException(AiException.Kind.INVALID_RESPONSE, e.message.orEmpty())
        }
    }

    private fun builder(url: String, apiKey: String): Request.Builder {
        val b = try {
            Request.Builder().url(normalize(url))
        } catch (e: IllegalArgumentException) {
            throw AiException(AiException.Kind.NOT_CONFIGURED, "Bad URL: $url")
        }
        if (apiKey.isNotBlank()) b.header("Authorization", "Bearer $apiKey")
        return b
    }

    suspend fun postJson(url: String, json: String, apiKey: String = ""): String =
        call(builder(url, apiKey).post(json.toRequestBody("application/json".toMediaType())).build()) {
            it.body?.string() ?: throw AiException(AiException.Kind.INVALID_RESPONSE, "Empty body")
        }

    suspend fun postJsonBytes(url: String, json: String, apiKey: String = ""): ByteArray =
        call(builder(url, apiKey).post(json.toRequestBody("application/json".toMediaType())).build()) {
            it.body?.bytes() ?: throw AiException(AiException.Kind.INVALID_RESPONSE, "Empty body")
        }

    suspend fun getString(url: String, apiKey: String = ""): String =
        call(builder(url, apiKey).get().build()) {
            it.body?.string() ?: throw AiException(AiException.Kind.INVALID_RESPONSE, "Empty body")
        }

    suspend fun getBytes(url: String, apiKey: String = ""): ByteArray =
        call(builder(url, apiKey).get().build()) {
            it.body?.bytes() ?: throw AiException(AiException.Kind.INVALID_RESPONSE, "Empty body")
        }

    private fun httpError(code: Int, body: String): AiException = when (code) {
        401, 403 -> AiException(AiException.Kind.INVALID_KEY, "HTTP $code $body")
        408, 504 -> AiException(AiException.Kind.TIMEOUT, "HTTP $code $body")
        in 500..599 -> AiException(AiException.Kind.SERVER_UNAVAILABLE, "HTTP $code $body")
        else -> AiException(AiException.Kind.GENERATION_FAILED, "HTTP $code $body")
    }

    companion object {
        fun normalize(url: String): String {
            val t = url.trim()
            return if (t.startsWith("http://") || t.startsWith("https://")) t else "http://$t"
        }

        fun join(base: String, path: String): String = normalize(base).trimEnd('/') + "/" + path.trimStart('/')
    }
}
