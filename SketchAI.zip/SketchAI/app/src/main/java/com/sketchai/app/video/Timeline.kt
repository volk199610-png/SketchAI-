package com.sketchai.app.video

import com.sketchai.app.audio.WavUtils
import com.sketchai.app.domain.Project
import com.sketchai.app.domain.Scene
import com.sketchai.app.domain.VoiceProfile
import java.io.File
import kotlin.math.max

data class LineSlot(val startMs: Long, val endMs: Long, val text: String, val audio: File?)

data class SceneSlot(val scene: Scene, val index: Int, val startMs: Long, val endMs: Long, val lines: List<LineSlot>) {
    val durationMs: Long get() = endMs - startMs
}

data class Timeline(val slots: List<SceneSlot>) {
    val totalMs: Long get() = slots.lastOrNull()?.endMs ?: 0L
    fun slotAt(ms: Long): SceneSlot? = slots.firstOrNull { ms >= it.startMs && ms < it.endMs } ?: slots.lastOrNull()
}

object TimelineBuilder {
    private const val LEAD_IN = 300L
    private const val GAP = 250L

    /**
     * Lays scenes out one after another. A scene lasts as long as the user set,
     * or longer if its dialogue (real voice length or an estimate) does not fit.
     */
    fun build(project: Project, audioFor: (String, VoiceProfile) -> File?): Timeline {
        var t = 0L
        val slots = ArrayList<SceneSlot>()
        project.scenes.forEachIndexed { i, sc ->
            var cursor = LEAD_IN
            val lines = ArrayList<LineSlot>()
            for (dl in sc.dialogue) {
                if (dl.text.isBlank()) continue
                val voice = project.characters.find { it.id == dl.characterId }?.voice ?: VoiceProfile()
                val file = audioFor(dl.text, voice)
                val real = file?.let { WavUtils.durationMs(it) } ?: -1L
                val d = if (real > 0) real else max(1200L, dl.text.length * 65L)
                lines += LineSlot(t + cursor, t + cursor + d, dl.text, if (real > 0) file else null)
                cursor += d + GAP
            }
            val speechEnd = if (lines.isEmpty()) 0L else cursor + 400L
            val dur = max((sc.durationSec * 1000).toLong(), speechEnd)
            slots += SceneSlot(sc, i, t, t + dur, lines)
            t += dur
        }
        return Timeline(slots)
    }
}
