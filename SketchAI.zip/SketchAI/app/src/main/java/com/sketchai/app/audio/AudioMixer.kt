package com.sketchai.app.audio

import com.sketchai.app.video.Timeline

object AudioMixer {
    const val RATE = 44100

    /** Mixes every spoken line onto one mono 44.1 kHz track. Returns null when there is nothing to mix. */
    fun mix(timeline: Timeline): ShortArray? {
        val lines = timeline.slots.flatMap { it.lines }.filter { it.audio != null }
        if (lines.isEmpty()) return null
        val total = (timeline.totalMs * RATE / 1000L).toInt() + RATE / 10
        val acc = IntArray(total)
        var mixed = 0
        for (l in lines) {
            val wav = runCatching { WavUtils.read(l.audio!!) }.getOrNull() ?: continue
            val mono = WavUtils.toMono(wav, RATE)
            val off = (l.startMs * RATE / 1000L).toInt()
            for (i in mono.indices) {
                val j = off + i
                if (j >= total) break
                acc[j] += mono[i]
            }
            mixed++
        }
        if (mixed == 0) return null
        return ShortArray(total) { acc[it].coerceIn(-32768, 32767).toShort() }
    }
}
