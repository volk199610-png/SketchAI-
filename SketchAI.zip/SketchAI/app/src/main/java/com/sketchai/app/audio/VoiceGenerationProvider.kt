package com.sketchai.app.audio

import android.content.Context
import android.os.Bundle
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import com.sketchai.app.data.AppSettings
import com.sketchai.app.domain.VoiceProfile
import com.sketchai.app.network.AiException
import com.sketchai.app.network.ApiClient
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.put
import java.io.File
import java.util.Locale
import java.util.UUID
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

/** Every provider writes a 16-bit PCM WAV file to [out] and returns it. */
interface VoiceGenerationProvider {
    suspend fun synthesize(text: String, voice: VoiceProfile, out: File): File
}

/** Local fallback: the device's own TextToSpeech engine. */
class AndroidTtsProvider(
    private val context: Context,
    private val settings: () -> AppSettings,
) : VoiceGenerationProvider {

    private var tts: TextToSpeech? = null
    private val mutex = Mutex()

    private suspend fun engine(): TextToSpeech {
        val existing = tts
        if (existing != null) return existing
        return withContext(Dispatchers.Main) {
            suspendCancellableCoroutine<TextToSpeech> { cont ->
                val holder = arrayOfNulls<TextToSpeech>(1)
                holder[0] = TextToSpeech(context.applicationContext) { status ->
                    val t = holder[0]
                    if (status == TextToSpeech.SUCCESS && t != null) {
                        tts = t
                        if (cont.isActive) cont.resume(t)
                    } else if (cont.isActive) {
                        cont.resumeWithException(AiException(AiException.Kind.GENERATION_FAILED, "Text-to-speech engine is not available"))
                    }
                }
            }
        }
    }

    override suspend fun synthesize(text: String, voice: VoiceProfile, out: File): File = mutex.withLock {
        val t = engine()
        withContext(Dispatchers.Main) {
            val loc = Locale(settings().language)
            val r = t.setLanguage(loc)
            if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED) t.setLanguage(Locale.getDefault())
            t.setPitch(voice.pitch)
            t.setSpeechRate(voice.rate)
        }
        suspendCancellableCoroutine<File> { cont ->
            val id = UUID.randomUUID().toString()
            t.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(utteranceId: String?) {}
                override fun onDone(utteranceId: String?) {
                    if (utteranceId == id && cont.isActive) cont.resume(out)
                }

                @Deprecated("Deprecated in Java")
                override fun onError(utteranceId: String?) {
                    if (utteranceId == id && cont.isActive) {
                        cont.resumeWithException(AiException(AiException.Kind.GENERATION_FAILED, "TTS failed"))
                    }
                }
            })
            out.parentFile?.mkdirs()
            val res = t.synthesizeToFile(text, Bundle(), out, id)
            if (res != TextToSpeech.SUCCESS && cont.isActive) {
                cont.resumeWithException(AiException(AiException.Kind.GENERATION_FAILED, "TTS rejected the text"))
            }
        }
    }
}

/** POST {backend}/audio/speech (OpenAI-compatible), requesting WAV output. */
class OpenAiTtsProvider(
    private val api: ApiClient,
    private val settings: () -> AppSettings,
) : VoiceGenerationProvider {

    override suspend fun synthesize(text: String, voice: VoiceProfile, out: File): File {
        val s = settings()
        if (!s.backendConfigured) throw AiException(AiException.Kind.NOT_CONFIGURED, "Backend URL is empty")
        val body = buildJsonObject {
            put("model", s.ttsModel)
            put("input", text)
            put("voice", voice.remoteVoice)
            put("response_format", "wav")
            put("speed", voice.rate.toDouble().coerceIn(0.25, 4.0))
        }.toString()
        val bytes = api.postJsonBytes(ApiClient.join(s.backendUrl, "audio/speech"), body, s.apiKey)
        withContext(Dispatchers.IO) {
            out.parentFile?.mkdirs()
            out.writeBytes(bytes)
        }
        return out
    }
}
