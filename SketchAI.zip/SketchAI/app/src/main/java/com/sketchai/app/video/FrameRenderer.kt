package com.sketchai.app.video

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import com.sketchai.app.domain.SubtitleAnim
import com.sketchai.app.domain.SubtitleFont
import com.sketchai.app.domain.SubtitleLook
import com.sketchai.app.domain.SubtitlePosition
import com.sketchai.app.domain.SubtitleStyle
import kotlin.math.min

/**
 * Draws any moment of the final video onto a Canvas. The same class feeds the
 * in-app preview and the MediaCodec exporter, so preview == export.
 * Not thread-safe: create one instance per thread.
 */
class FrameRenderer(
    private val timeline: Timeline,
    bitmaps: Map<String, Bitmap>,
    private val style: SubtitleStyle,
    provider: VideoGenerationProvider = LocalBoilVideoProvider(),
) {
    private val clips: Map<Int, SceneClip> = timeline.slots.mapNotNull { slot ->
        bitmaps[slot.scene.id]?.let { bmp -> slot.index to provider.createClip(slot.scene, slot.index, bmp, slot.durationMs) }
    }.toMap()

    private val placeholder = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.LTGRAY; textAlign = Paint.Align.CENTER; typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD)
    }
    private val subPaint = TextPaint(Paint.ANTI_ALIAS_FLAG)
    private val boxPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val box = RectF()

    fun draw(canvas: Canvas, w: Int, h: Int, timeMs: Long) {
        canvas.drawColor(Color.WHITE)
        val slot = timeline.slotAt(timeMs) ?: return
        val local = (timeMs - slot.startMs).coerceAtLeast(0L)
        val clip = clips[slot.index]
        if (clip != null) {
            clip.draw(canvas, w, h, local)
        } else {
            placeholder.textSize = min(w, h) * 0.06f
            canvas.drawText("Scene ${slot.index + 1}", w / 2f, h / 2f, placeholder)
        }
        val line = slot.lines.firstOrNull { timeMs >= it.startMs && timeMs < it.endMs }
        if (line != null) drawSubtitle(canvas, w, h, line, timeMs)
    }

    private fun typeface(f: SubtitleFont): Typeface = when (f) {
        SubtitleFont.SANS -> Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD)
        SubtitleFont.SERIF -> Typeface.create(Typeface.SERIF, Typeface.BOLD)
        SubtitleFont.MONO -> Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)
        SubtitleFont.HAND -> Typeface.create("cursive", Typeface.BOLD)
    }

    private fun drawSubtitle(canvas: Canvas, w: Int, h: Int, line: LineSlot, t: Long) {
        val unit = min(w, h) / 1080f
        val lt = t - line.startMs
        val ld = (line.endMs - line.startMs).coerceAtLeast(1L)
        var text = line.text
        var alpha = 255
        when (style.anim) {
            SubtitleAnim.FADE -> alpha = (255 * min(1f, lt / 250f)).toInt().coerceIn(0, 255)
            SubtitleAnim.TYPEWRITER -> {
                val n = (text.length * min(1f, lt / (ld * 0.7f))).toInt().coerceIn(1, text.length)
                text = text.take(n)
            }
            SubtitleAnim.NONE -> {}
        }
        subPaint.reset()
        subPaint.isAntiAlias = true
        subPaint.textSize = style.size * unit
        subPaint.typeface = typeface(style.font)

        val maxW = (w * 0.84f).toInt()
        val layout = StaticLayout.Builder.obtain(text, 0, text.length, subPaint, maxW)
            .setAlignment(Layout.Alignment.ALIGN_CENTER).build()
        var lineW = 0f
        for (i in 0 until layout.lineCount) lineW = maxOf(lineW, layout.getLineWidth(i))
        val x = (w - maxW) / 2f
        val margin = h * 0.08f
        val y = when (style.position) {
            SubtitlePosition.TOP -> margin
            SubtitlePosition.CENTER -> (h - layout.height) / 2f
            SubtitlePosition.BOTTOM -> h - margin - layout.height
        }
        val black = style.look == SubtitleLook.WHITE_STROKE
        if (style.background) {
            val pad = 24f * unit
            box.set((w - lineW) / 2f - pad, y - pad * 0.6f, (w + lineW) / 2f + pad, y + layout.height + pad * 0.6f)
            boxPaint.style = Paint.Style.FILL
            boxPaint.color = if (black) Color.argb(200, 0, 0, 0) else Color.WHITE
            boxPaint.alpha = if (black) (200 * alpha / 255) else alpha
            canvas.drawRoundRect(box, 18f * unit, 18f * unit, boxPaint)
            if (!black) {
                boxPaint.style = Paint.Style.STROKE
                boxPaint.strokeWidth = 4f * unit
                boxPaint.color = Color.BLACK
                boxPaint.alpha = alpha
                canvas.drawRoundRect(box, 18f * unit, 18f * unit, boxPaint)
            }
        }
        canvas.save()
        canvas.translate(x, y)
        // Outline pass
        subPaint.style = Paint.Style.STROKE
        subPaint.strokeJoin = Paint.Join.ROUND
        subPaint.strokeWidth = 9f * unit
        subPaint.color = if (black) Color.BLACK else Color.WHITE
        subPaint.alpha = if (style.background && !black) 0 else alpha
        if (subPaint.alpha > 0) layout.draw(canvas)
        // Fill pass
        subPaint.style = Paint.Style.FILL
        subPaint.color = if (black) Color.WHITE else Color.BLACK
        subPaint.alpha = alpha
        layout.draw(canvas)
        canvas.restore()
    }
}
