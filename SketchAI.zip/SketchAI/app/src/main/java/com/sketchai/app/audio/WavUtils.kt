package com.sketchai.app.audio

import java.io.File
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.concurrent.ConcurrentHashMap

class WavPcm(val sampleRate: Int, val channels: Int, val samples: ShortArray)

object WavUtils {
    private val durationCache = ConcurrentHashMap<String, Long>()

    /** Reads a 16-bit PCM WAV file. Throws IllegalArgumentException if the format is not supported. */
    fun read(file: File): WavPcm {
        val bytes = file.readBytes()
        require(bytes.size > 44) { "WAV too short" }
        val bb = ByteBuffer.wrap(bytes).order(ByteOrder.LITTLE_ENDIAN)
        require(tag(bytes, 0) == "RIFF" && tag(bytes, 8) == "WAVE") { "Not a WAV file" }
        var pos = 12
        var sampleRate = 0
        var channels = 0
        var bits = 0
        while (pos + 8 <= bytes.size) {
            val id = tag(bytes, pos)
            var size = bb.getInt(pos + 4)
            val body = pos + 8
            if (id == "fmt ") {
                channels = bb.getShort(body + 2).toInt()
                sampleRate = bb.getInt(body + 4)
                bits = bb.getShort(body + 14).toInt()
            } else if (id == "data") {
                require(bits == 16 && channels > 0 && sampleRate > 0) { "Only 16-bit PCM is supported" }
                if (size < 0 || body + size > bytes.size) size = bytes.size - body
                val count = size / 2
                val out = ShortArray(count)
                bb.position(body)
                bb.asShortBuffer().get(out)
                return WavPcm(sampleRate, channels, out)
            }
            if (size < 0) break
            pos = body + size + (size and 1)
        }
        throw IllegalArgumentException("No data chunk")
    }

    fun durationMs(file: File): Long {
        val key = file.path + ":" + file.lastModified()
        return durationCache.getOrPut(key) {
            runCatching {
                val w = read(file)
                w.samples.size.toLong() * 1000L / (w.sampleRate.toLong() * w.channels)
            }.getOrDefault(-1L)
        }
    }

    /** Down-mix to mono and resample (linear) to [targetRate]. */
    fun toMono(wav: WavPcm, targetRate: Int): ShortArray {
        val ch = wav.channels
        val frames = wav.samples.size / ch
        val mono = ShortArray(frames) { i ->
            var sum = 0
            for (c in 0 until ch) sum += wav.samples[i * ch + c]
            (sum / ch).toShort()
        }
        if (wav.sampleRate == targetRate) return mono
        val ratio = wav.sampleRate.toDouble() / targetRate
        val outLen = (frames / ratio).toInt()
        return ShortArray(outLen) { i ->
            val pos = i * ratio
            val i0 = pos.toInt().coerceAtMost(frames - 1)
            val i1 = (i0 + 1).coerceAtMost(frames - 1)
            val f = (pos - i0).toFloat()
            (mono[i0] * (1f - f) + mono[i1] * f).toInt().toShort()
        }
    }

    private fun tag(b: ByteArray, off: Int) = String(b, off, 4, Charsets.ISO_8859_1)
}
