package com.sketchai.app

import android.app.Application
import com.sketchai.app.di.AppContainer

class SketchApp : Application() {
    lateinit var container: AppContainer
        private set

    override fun onCreate() {
        super.onCreate()
        container = AppContainer(this)
    }
}
