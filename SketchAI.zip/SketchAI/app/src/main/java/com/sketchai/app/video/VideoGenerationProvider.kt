package com.sketchai.app.video

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.RectF
import com.sketchai.app.domain.Scene
import kotlin.math.min
import kotlin.random.Random

/** A ready-to-play animation of one scene. Must be cheap: it is called for every video frame. */
interface SceneClip {
    fun draw(canvas: Canvas, w: Int, h: Int, timeMs: Long)
}

/**
 * Turns a scene image into an animation. Implementations can be local (below) or remote
 * (image-to-video backends returning frames), without touching the editor or exporter.
 */
interface VideoGenerationProvider {
    val name: String
    fun createClip(scene: Scene, sceneIndex: Int, image: Bitmap, durationMs: Long): SceneClip
}

/**
 * Local "boiling line" animation: slow push-in, a few pixels of jitter every ~120 ms
 * (like redrawn frames in hand-drawn cartoons) and a short fade-in. Always black and white.
 */
class LocalBoilVideoProvider : VideoGenerationProvider {
    override val name = "Local boil animation"

    override fun createClip(scene: Scene, sceneIndex: Int, image: Bitmap, durationMs: Long): SceneClip =
        BoilClip(image, sceneIndex, durationMs)

    private class BoilClip(val bmp: Bitmap, val seed: Int, val durationMs: Long) : SceneClip {
        private val paint = Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG).apply {
            colorFilter = ColorMatrixColorFilter(ColorMatrix().apply { setSaturation(0f) })
        }
        private val src = Rect()
        private val dst = RectF()

        override fun draw(canvas: Canvas, w: Int, h: Int, timeMs: Long) {
            val p = if (durationMs > 0) min(1f, timeMs.toFloat() / durationMs) else 0f
            val rng = Random((timeMs / 120L) * 7919L + seed)
            val dx = (rng.nextFloat() - 0.5f) * w * 0.008f
            val dy = (rng.nextFloat() - 0.5f) * w * 0.008f
            val rot = (rng.nextFloat() - 0.5f) * 0.8f
            val scale = 1f + 0.05f * p
            paint.alpha = (255 * min(1f, timeMs / 250f)).toInt().coerceIn(0, 255)

            // Center-crop the bitmap to the frame aspect ratio.
            val bw = bmp.width
            val bh = bmp.height
            val aspect = w.toFloat() / h
            if (bw.toFloat() / bh > aspect) {
                val sw = (bh * aspect).toInt()
                src.set((bw - sw) / 2, 0, (bw - sw) / 2 + sw, bh)
            } else {
                val sh = (bw / aspect).toInt()
                src.set(0, (bh - sh) / 2, bw, (bh - sh) / 2 + sh)
            }
            dst.set(-w / 2f, -h / 2f, w / 2f, h / 2f)

            canvas.save()
            canvas.translate(w / 2f + dx, h / 2f + dy)
            canvas.rotate(rot)
            canvas.scale(scale, scale)
            canvas.drawBitmap(bmp, src, dst, paint)
            canvas.restore()
        }
    }
}
