package com.sketchai.app.presentation

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.sketchai.app.R
import com.sketchai.app.di.AppContainer
import com.sketchai.app.domain.AspectFormat
import com.sketchai.app.domain.ComedyRequest
import com.sketchai.app.domain.Genre
import com.sketchai.app.domain.Project
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class HomeState(
    val idea: String = "",
    val genre: Genre = Genre.BLACK_HUMOR,
    val humor: Int = 70,
    val duration: Int = 15,
    val characters: Int = 2,
    val format: AspectFormat = AspectFormat.PORTRAIT,
    val busy: Boolean = false,
    val message: UiMessage? = null,
)

class HomeViewModel(private val c: AppContainer) : ViewModel() {

    private val _state = MutableStateFlow(
        c.settings.state.value.let {
            HomeState(humor = it.defaultHumor, duration = it.defaultDuration, format = it.defaultFormat)
        },
    )
    val state: StateFlow<HomeState> = _state.asStateFlow()
    val settings = c.settings.state

    fun edit(f: (HomeState) -> HomeState) = _state.update(f)
    fun dismissMessage() = _state.update { it.copy(message = null) }

    fun generate(onCreated: (Long) -> Unit) {
        val s = _state.value
        if (s.idea.isBlank() || s.busy) return
        _state.update { it.copy(busy = true, message = null) }
        viewModelScope.launch {
            try {
                val result = c.comedy.generate(
                    ComedyRequest(s.idea.trim(), s.humor, s.genre, s.duration, s.characters, c.settings.state.value.defaultVoice),
                )
                val project = Project(
                    title = result.title.ifBlank { s.idea.take(40) },
                    createdAt = System.currentTimeMillis(),
                    idea = s.idea.trim(), genre = s.genre, humorLevel = s.humor,
                    targetDurationSec = s.duration, format = s.format,
                    characters = result.characters, scenes = result.scenes,
                )
                val id = c.projects.save(project)
                _state.update {
                    it.copy(busy = false, message = if (result.usedFallback) UiMessage(R.string.warn_llm_fallback, isError = false) else null)
                }
                onCreated(id)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                _state.update { it.copy(busy = false, message = e.toUiMessage()) }
            }
        }
    }
}
