package com.sketchai.app.ai

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PointF
import android.graphics.Typeface
import com.sketchai.app.domain.Beat
import com.sketchai.app.domain.Character
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.random.Random

/**
 * Always-available provider: draws hand-made looking stick figures with Canvas.
 * Uses character traits (hair, glasses, hat, tie, beard) so each character stays recognisable.
 */
class LocalSketchImageProvider : ImageGenerationProvider {

    override val name = "Local sketch"

    private enum class Pose { STAND, WAVE, RUN, FALL, LIE }

    override suspend fun generateImage(request: ImageRequest): Bitmap = withContext(Dispatchers.Default) {
        render(request)
    }

    private fun render(r: ImageRequest): Bitmap {
        val w = r.format.w
        val h = r.format.h
        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        c.drawColor(Color.WHITE)
        val rng = Random(r.seed)
        val unit = min(w, h).toFloat()
        val stroke = unit * 0.009f
        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.BLACK; style = Paint.Style.STROKE; strokeWidth = stroke
            strokeCap = Paint.Cap.ROUND; strokeJoin = Paint.Join.ROUND
        }
        val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.BLACK; style = Paint.Style.FILL }
        val label = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.BLACK; textSize = unit * 0.036f; textAlign = Paint.Align.CENTER
            typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD)
        }

        val ground = h * (if (w > h) 0.80f else 0.68f)
        poly(c, paint, listOf(PointF(unit * 0.04f, ground), PointF(w - unit * 0.04f, ground)), rng, stroke * 0.4f)
        repeat(7) {
            val gx = rng.nextFloat() * (w - unit * 0.2f) + unit * 0.1f
            val gy = ground + unit * (0.02f + rng.nextFloat() * 0.05f)
            poly(c, paint, listOf(PointF(gx, gy), PointF(gx + unit * 0.05f, gy)), rng, 1f)
        }

        val chars = r.scene.characterIds.mapNotNull { id -> r.characters.find { it.id == id } }
        val n = max(1, chars.size)
        val figH = min(h * 0.36f, w * 0.55f / max(1f, n * 0.75f))
        val speakerId = r.scene.dialogue.firstOrNull()?.characterId

        chars.forEachIndexed { i, ch ->
            val cx = w * (i + 1f) / (chars.size + 1f)
            val isSpeaker = ch.id == speakerId
            val pose = when (r.scene.beat) {
                Beat.SETUP -> Pose.STAND
                Beat.BUILD_UP -> if (isSpeaker) Pose.WAVE else Pose.STAND
                Beat.PAUSE -> Pose.STAND
                Beat.PUNCHLINE -> if (isSpeaker) Pose.WAVE else if (i % 2 == 0) Pose.RUN else Pose.FALL
                Beat.ENDING -> if (i == chars.lastIndex) Pose.LIE else Pose.STAND
            }
            val top = figure(c, paint, fill, rng, cx, ground, figH, pose, ch, r.scene.beat)
            label.textSize = unit * (if (chars.size > 2) 0.028f else 0.036f)
            c.drawText(ch.name.take(14), top.x, top.y - unit * 0.025f, label)
        }

        // Mood marks.
        val marks = Paint(label).apply { textSize = unit * 0.11f }
        when (r.scene.beat) {
            Beat.PAUSE -> c.drawText("...", w / 2f, ground - figH * 1.35f, marks)
            Beat.PUNCHLINE -> c.drawText("!", w / 2f, ground - figH * 1.35f, marks)
            else -> {}
        }
        return bmp
    }

    /** Draws one figure and returns the point above its head (for the name label). */
    private fun figure(
        c: Canvas, p: Paint, fill: Paint, rng: Random,
        cx: Float, gy: Float, u: Float, pose: Pose, ch: Character, beat: Beat,
    ): PointF {
        fun pt(dx: Float, dy: Float) = PointF(cx + dx * u, gy - dy * u)
        val amp = p.strokeWidth * 0.35f
        val headR = 0.12f * u
        val traits = ch.traitsText()

        val headC: PointF = if (pose == Pose.LIE) PointF(cx - 0.45f * u, gy - headR) else pt(0f, 0.88f)
        if (pose == Pose.LIE) {
            val hx = cx - 0.45f * u
            val hy = gy - headR
            circle(c, p, hx, hy, headR, rng)
            poly(c, p, listOf(PointF(hx + headR, hy), PointF(hx + 0.55f * u, hy)), rng, amp)
            poly(c, p, listOf(PointF(hx + 0.55f * u, hy), PointF(hx + 0.85f * u, hy - 0.08f * u)), rng, amp)
            poly(c, p, listOf(PointF(hx + 0.55f * u, hy), PointF(hx + 0.85f * u, hy + 0.05f * u)), rng, amp)
            poly(c, p, listOf(PointF(hx + 0.25f * u, hy), PointF(hx + 0.35f * u, hy - 0.15f * u)), rng, amp)
            face(c, p, fill, headC, headR, beat, rng)
            return PointF(hx, hy - headR)
        }

        circle(c, p, headC.x, headC.y, headR, rng)
        poly(c, p, listOf(pt(0f, 0.76f), pt(0f, 0.40f)), rng, amp)
        when (pose) {
            Pose.WAVE -> {
                poly(c, p, listOf(pt(0f, 0.68f), pt(-0.15f, 0.50f)), rng, amp)
                poly(c, p, listOf(pt(0f, 0.68f), pt(0.17f, 0.85f), pt(0.25f, 0.95f)), rng, amp)
                poly(c, p, listOf(pt(0f, 0.40f), pt(-0.10f, 0f)), rng, amp)
                poly(c, p, listOf(pt(0f, 0.40f), pt(0.10f, 0f)), rng, amp)
            }
            Pose.RUN -> {
                poly(c, p, listOf(pt(0f, 0.68f), pt(0.18f, 0.60f), pt(0.30f, 0.70f)), rng, amp)
                poly(c, p, listOf(pt(0f, 0.68f), pt(-0.20f, 0.58f), pt(-0.30f, 0.48f)), rng, amp)
                poly(c, p, listOf(pt(0f, 0.40f), pt(0.20f, 0.25f), pt(0.30f, 0f)), rng, amp)
                poly(c, p, listOf(pt(0f, 0.40f), pt(-0.15f, 0.20f), pt(-0.30f, 0.08f)), rng, amp)
            }
            Pose.FALL -> {
                poly(c, p, listOf(pt(0f, 0.68f), pt(-0.25f, 0.85f)), rng, amp)
                poly(c, p, listOf(pt(0f, 0.68f), pt(0.25f, 0.85f)), rng, amp)
                poly(c, p, listOf(pt(0f, 0.40f), pt(-0.20f, 0.10f)), rng, amp)
                poly(c, p, listOf(pt(0f, 0.40f), pt(0.20f, 0.20f)), rng, amp)
            }
            else -> {
                poly(c, p, listOf(pt(0f, 0.68f), pt(-0.17f, 0.45f)), rng, amp)
                poly(c, p, listOf(pt(0f, 0.68f), pt(0.17f, 0.45f)), rng, amp)
                poly(c, p, listOf(pt(0f, 0.40f), pt(-0.09f, 0f)), rng, amp)
                poly(c, p, listOf(pt(0f, 0.40f), pt(0.09f, 0f)), rng, amp)
            }
        }
        face(c, p, fill, headC, headR, beat, rng)

        // Hair
        when {
            traits.contains("bald") || traits.contains("лыс") -> {}
            traits.contains("long") || traits.contains("длин") -> {
                poly(c, p, listOf(PointF(headC.x - headR, headC.y - headR * 0.3f), PointF(headC.x - headR * 1.1f, headC.y + headR * 1.6f)), rng, amp)
                poly(c, p, listOf(PointF(headC.x + headR, headC.y - headR * 0.3f), PointF(headC.x + headR * 1.1f, headC.y + headR * 1.6f)), rng, amp)
                poly(c, p, listOf(PointF(headC.x - headR, headC.y - headR * 0.3f), PointF(headC.x, headC.y - headR * 1.15f), PointF(headC.x + headR, headC.y - headR * 0.3f)), rng, amp)
            }
            else -> for (k in -2..2) {
                val bx = headC.x + k * headR * 0.38f
                val by = headC.y - headR * sqrtClamp(1f - (k * 0.38f) * (k * 0.38f))
                poly(c, p, listOf(PointF(bx, by), PointF(bx + k * headR * 0.15f, by - headR * 0.4f)), rng, amp * 0.5f)
            }
        }
        // Accessories
        if (traits.contains("glass") || traits.contains("очк")) {
            val er = headR * 0.3f
            circle(c, p, headC.x - headR * 0.42f, headC.y - headR * 0.1f, er, rng)
            circle(c, p, headC.x + headR * 0.42f, headC.y - headR * 0.1f, er, rng)
            poly(c, p, listOf(PointF(headC.x - headR * 0.12f, headC.y - headR * 0.1f), PointF(headC.x + headR * 0.12f, headC.y - headR * 0.1f)), rng, 0.5f)
        }
        if (traits.contains("hat") || traits.contains("cap") || traits.contains("шляп") || traits.contains("кеп")) {
            val ty = headC.y - headR * 0.95f
            poly(c, p, listOf(PointF(headC.x - headR * 1.5f, ty), PointF(headC.x + headR * 1.5f, ty)), rng, amp)
            poly(c, p, listOf(PointF(headC.x - headR * 0.8f, ty), PointF(headC.x - headR * 0.8f, ty - headR * 0.9f), PointF(headC.x + headR * 0.8f, ty - headR * 0.9f), PointF(headC.x + headR * 0.8f, ty)), rng, amp)
        }
        if (traits.contains("tie") || traits.contains("галстук") || traits.contains("suit")) {
            val s = pt(0f, 0.70f)
            val e = pt(0f, 0.55f)
            poly(c, p, listOf(s, PointF(s.x - u * 0.03f, s.y + u * 0.04f), e, PointF(s.x + u * 0.03f, s.y + u * 0.04f), s), rng, 0.5f)
        }
        if (traits.contains("beard") || traits.contains("боро")) {
            val steps = 8
            val pts = (0..steps).map { k ->
                val a = PI.toFloat() * 0.15f + PI.toFloat() * 0.7f * k / steps
                PointF(headC.x + cos(a) * headR * 1.05f, headC.y + sin(a) * headR * 1.1f)
            }
            poly(c, p, pts, rng, 0.5f)
        }
        return PointF(headC.x, headC.y - headR * (if (traits.contains("hat") || traits.contains("шляп")) 2.3f else 1.3f))
    }

    private fun sqrtClamp(v: Float): Float = kotlin.math.sqrt(v.coerceAtLeast(0f))

    private fun face(c: Canvas, p: Paint, fill: Paint, h: PointF, r: Float, beat: Beat, rng: Random) {
        val er = max(2f, p.strokeWidth * 0.55f)
        c.drawCircle(h.x - r * 0.38f, h.y - r * 0.12f, er, fill)
        c.drawCircle(h.x + r * 0.38f, h.y - r * 0.12f, er, fill)
        when (beat) {
            Beat.PUNCHLINE -> circle(c, p, h.x, h.y + r * 0.45f, r * 0.16f, rng)
            Beat.ENDING -> poly(c, p, listOf(PointF(h.x - r * 0.3f, h.y + r * 0.5f), PointF(h.x + r * 0.3f, h.y + r * 0.5f)), rng, 0.4f)
            else -> poly(c, p, listOf(PointF(h.x - r * 0.3f, h.y + r * 0.45f), PointF(h.x + r * 0.3f, h.y + r * 0.45f)), rng, 0.4f)
        }
    }

    // ---- hand-drawn primitives -------------------------------------------------------------

    private fun poly(c: Canvas, p: Paint, pts: List<PointF>, rng: Random, amp: Float) {
        val path = Path()
        var first = true
        for (i in 0 until pts.size - 1) {
            val a = pts[i]
            val b = pts[i + 1]
            val steps = max(1, (hypot(b.x - a.x, b.y - a.y) / 14f).toInt())
            for (k in 0 until steps) {
                val t = k.toFloat() / steps
                val x = a.x + (b.x - a.x) * t + (rng.nextFloat() - 0.5f) * 2f * amp
                val y = a.y + (b.y - a.y) * t + (rng.nextFloat() - 0.5f) * 2f * amp
                if (first) { path.moveTo(x, y); first = false } else path.lineTo(x, y)
            }
        }
        val last = pts.last()
        path.lineTo(last.x + (rng.nextFloat() - 0.5f) * amp, last.y + (rng.nextFloat() - 0.5f) * amp)
        c.drawPath(path, p)
    }

    private fun circle(c: Canvas, p: Paint, cx: Float, cy: Float, r: Float, rng: Random) {
        val n = max(18, (r * 0.6f).toInt())
        val off = rng.nextFloat() * (2 * PI.toFloat())
        val path = Path()
        for (k in 0..n) {
            val a = off + 2f * PI.toFloat() * k / n * 1.04f
            val rr = r + (rng.nextFloat() - 0.5f) * p.strokeWidth * 0.5f
            val x = cx + rr * cos(a)
            val y = cy + rr * sin(a)
            if (k == 0) path.moveTo(x, y) else path.lineTo(x, y)
        }
        c.drawPath(path, p)
    }
}
