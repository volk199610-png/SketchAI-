package com.sketchai.app.utils

import android.content.Context
import java.io.File

/** Where per-project binary files (scene images, voice clips) live. */
class ProjectFiles(private val context: Context) {
    fun dir(projectId: Long): File = File(context.filesDir, "projects/$projectId").apply { mkdirs() }
    fun audioDir(projectId: Long): File = File(dir(projectId), "audio").apply { mkdirs() }
    fun imageFile(projectId: Long, name: String): File = File(dir(projectId), name)
    fun cacheDir(): File = context.cacheDir
    fun deleteProject(projectId: Long) {
        File(context.filesDir, "projects/$projectId").deleteRecursively()
    }
}
