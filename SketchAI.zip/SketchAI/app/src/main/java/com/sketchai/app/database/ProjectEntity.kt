package com.sketchai.app.database

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "projects")
data class ProjectEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val createdAt: Long,
    val durationSec: Float,
    val sceneCount: Int,
    val thumbnailPath: String?,
    val json: String,
)
