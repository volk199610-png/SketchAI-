package com.sketchai.app.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.Card
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.sketchai.app.R
import com.sketchai.app.domain.Character
import com.sketchai.app.domain.VoicePreset
import com.sketchai.app.presentation.ProjectState
import com.sketchai.app.presentation.ProjectViewModel
import java.util.Locale

@Composable
fun CharactersTab(st: ProjectState, vm: ProjectViewModel) {
    val p = st.project ?: return
    val newName = stringResource(R.string.new_character_name, p.characters.size + 1)
    LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item {
            Text(stringResource(R.string.characters_note), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        items(p.characters, key = { it.id }) { ch -> CharacterCard(ch, p.characters.size > 1, vm) }
        item {
            OutlinedButton(onClick = { vm.addCharacter(newName) }, modifier = Modifier.fillMaxWidth()) {
                Icon(Icons.Filled.Add, null)
                Text(stringResource(R.string.add_character), modifier = Modifier.padding(start = 8.dp))
            }
        }
    }
}

@Composable
private fun CharacterCard(ch: Character, canDelete: Boolean, vm: ProjectViewModel) {
    fun upd(f: (Character) -> Character) = vm.updateCharacter(ch.id, f)
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(ch.id, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f), style = MaterialTheme.typography.labelLarge)
                IconButton({ vm.deleteCharacter(ch.id) }, enabled = canDelete) { Icon(Icons.Filled.Delete, null) }
            }
            EditField(ch.name, { v -> upd { it.copy(name = v) } }, stringResource(R.string.f_name), resetKey = ch.id, singleLine = true)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Column(Modifier.weight(1f)) { EditField(ch.gender, { v -> upd { it.copy(gender = v) } }, stringResource(R.string.f_gender), resetKey = ch.id, singleLine = true) }
                Column(Modifier.weight(1f)) { EditField(ch.age, { v -> upd { it.copy(age = v) } }, stringResource(R.string.f_age), resetKey = ch.id, singleLine = true) }
            }
            EditField(ch.hair, { v -> upd { it.copy(hair = v) } }, stringResource(R.string.f_hair), resetKey = ch.id)
            EditField(ch.face, { v -> upd { it.copy(face = v) } }, stringResource(R.string.f_face), resetKey = ch.id)
            EditField(ch.body, { v -> upd { it.copy(body = v) } }, stringResource(R.string.f_body), resetKey = ch.id)
            EditField(ch.clothes, { v -> upd { it.copy(clothes = v) } }, stringResource(R.string.f_clothes), resetKey = ch.id)
            EditField(ch.accessories, { v -> upd { it.copy(accessories = v) } }, stringResource(R.string.f_accessories), resetKey = ch.id)
            EditField(ch.personality, { v -> upd { it.copy(personality = v) } }, stringResource(R.string.f_personality), resetKey = ch.id)
            EditField(ch.visualDescription, { v -> upd { it.copy(visualDescription = v) } }, stringResource(R.string.f_visual), resetKey = ch.id, minLines = 2)

            Text(stringResource(R.string.voice), style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            ChipRow(
                VoicePreset.entries,
                VoicePreset.entries.firstOrNull { it.name == ch.voice.preset } ?: VoicePreset.MALE_CALM,
                { pr -> upd { it.copy(voice = pr.toProfile()) } },
            ) { it.label() }
            Text(stringResource(R.string.voice_pitch, String.format(Locale.US, "%.2f", ch.voice.pitch)), style = MaterialTheme.typography.bodySmall)
            Slider(ch.voice.pitch, { v -> upd { it.copy(voice = it.voice.copy(pitch = v)) } }, valueRange = 0.5f..2f)
            Text(stringResource(R.string.voice_rate, String.format(Locale.US, "%.2f", ch.voice.rate)), style = MaterialTheme.typography.bodySmall)
            Slider(ch.voice.rate, { v -> upd { it.copy(voice = it.voice.copy(rate = v)) } }, valueRange = 0.5f..2f)
        }
    }
}
