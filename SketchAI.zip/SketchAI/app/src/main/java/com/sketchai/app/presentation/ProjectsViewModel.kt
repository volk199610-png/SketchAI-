package com.sketchai.app.presentation

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.sketchai.app.database.ProjectEntity
import com.sketchai.app.di.AppContainer
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class ProjectsViewModel(private val c: AppContainer) : ViewModel() {
    val items: StateFlow<List<ProjectEntity>> =
        c.projects.observeSummaries().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun rename(id: Long, title: String) { viewModelScope.launch { c.projects.rename(id, title.trim().ifBlank { "Untitled" }) } }
    fun duplicate(id: Long) { viewModelScope.launch { c.projects.duplicate(id) } }
    fun delete(id: Long) { viewModelScope.launch { c.projects.delete(id) } }
}
