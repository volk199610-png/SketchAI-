package com.sketchai.app.ui

import android.content.Intent
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.RecordVoiceOver
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilledIconButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.min
import com.sketchai.app.R
import com.sketchai.app.audio.LinePlayer
import com.sketchai.app.domain.AspectFormat
import com.sketchai.app.domain.SubtitleAnim
import com.sketchai.app.domain.SubtitleFont
import com.sketchai.app.domain.SubtitleLook
import com.sketchai.app.domain.SubtitlePosition
import com.sketchai.app.presentation.ProjectState
import com.sketchai.app.presentation.ProjectViewModel
import com.sketchai.app.video.FrameRenderer
import java.util.Locale
import kotlin.math.roundToInt

private fun fmt(ms: Long): String {
    val s = (ms / 1000).toInt()
    return String.format(Locale.US, "%d:%02d", s / 60, s % 60)
}

@Composable
fun PreviewTab(st: ProjectState, vm: ProjectViewModel) {
    val p = st.project ?: return
    val ctx = LocalContext.current
    val timeline = st.timeline
    val total = timeline.totalMs

    var playing by remember { mutableStateOf(false) }
    var timeMs by remember { mutableLongStateOf(0L) }
    val player = remember { LinePlayer() }
    val played = remember { HashSet<String>() }
    val tl by rememberUpdatedState(timeline)
    DisposableEffect(Unit) { onDispose { player.stop() } }

    val renderer = remember(timeline, st.bitmaps, p.subtitle) { FrameRenderer(timeline, st.bitmaps, p.subtitle) }

    LaunchedEffect(playing) {
        if (!playing) { player.stop(); return@LaunchedEffect }
        if (timeMs >= tl.totalMs - 50) timeMs = 0L
        played.clear()
        val base = timeMs
        val start = withFrameNanos { it }
        while (true) {
            val now = withFrameNanos { it }
            timeMs = base + (now - start) / 1_000_000L
            if (timeMs >= tl.totalMs) { playing = false; timeMs = 0L; break }
            for (slot in tl.slots) slot.lines.forEachIndexed { k, l ->
                val key = "${slot.index}_$k"
                if (l.audio != null && timeMs >= l.startMs && key !in played) {
                    played.add(key)
                    if (timeMs - l.startMs < 400) player.play(l.audio)
                }
            }
        }
    }

    val slot = timeline.slotAt(timeMs)
    val selIndex = slot?.index ?: 0
    val scene = p.scenes.getOrNull(selIndex)
    val ratio = p.format.ratio

    Column(
        Modifier.verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        // ---- player ----
        BoxWithConstraints(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
            val w = min(maxWidth, 380.dp * ratio)
            Canvas(Modifier.width(w).aspectRatio(ratio).border(1.dp, MaterialTheme.colorScheme.outline)) {
                drawIntoCanvas { c -> renderer.draw(c.nativeCanvas, size.width.toInt(), size.height.toInt(), timeMs) }
            }
        }
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilledIconButton(onClick = { playing = !playing }) {
                Icon(if (playing) Icons.Filled.Pause else Icons.Filled.PlayArrow, null)
            }
            Slider(
                value = timeMs.toFloat().coerceIn(0f, total.toFloat().coerceAtLeast(1f)),
                onValueChange = { v ->
                    timeMs = v.toLong(); player.stop(); played.clear()
                    tl.slots.forEach { s -> s.lines.forEachIndexed { k, l -> if (l.startMs < timeMs) played.add("${s.index}_$k") } }
                },
                valueRange = 0f..total.toFloat().coerceAtLeast(1f),
                modifier = Modifier.weight(1f),
            )
            Text(fmt(timeMs) + " / " + fmt(total), style = MaterialTheme.typography.bodySmall)
        }

        // ---- timeline ----
        Row(Modifier.fillMaxWidth().height(44.dp), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            timeline.slots.forEach { s ->
                val selected = s.index == selIndex
                Surface(
                    modifier = Modifier.weight(s.durationMs.toFloat().coerceAtLeast(500f)).height(44.dp)
                        .clickable { timeMs = s.startMs; player.stop(); played.clear() },
                    shape = MaterialTheme.shapes.small,
                    color = if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant,
                    contentColor = if (selected) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurface,
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                ) {
                    Box(contentAlignment = Alignment.Center) { Text("${s.index + 1}", fontWeight = FontWeight.Bold) }
                }
            }
        }

        // ---- selected scene controls ----
        if (scene != null) {
            Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
                Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text(stringResource(R.string.scene_n, selIndex + 1) + " · " + scene.beat.label(), fontWeight = FontWeight.Bold)
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        IconButton({ vm.moveScene(scene.id, -1) }, enabled = selIndex > 0) { Icon(Icons.AutoMirrored.Filled.ArrowBack, null) }
                        IconButton({ vm.moveScene(scene.id, 1) }, enabled = selIndex < p.scenes.lastIndex) { Icon(Icons.AutoMirrored.Filled.ArrowForward, null) }
                        IconButton({ vm.regenerateScene(scene.id) }, enabled = st.busyText == null) { Icon(Icons.Filled.Refresh, null) }
                        IconButton({ vm.deleteScene(scene.id) }, enabled = p.scenes.size > 1) { Icon(Icons.Filled.Delete, null) }
                    }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(stringResource(R.string.duration_s, String.format(Locale.US, "%.1f", scene.durationSec)), Modifier.weight(1f))
                        IconButton({ vm.updateScene(scene.id) { it.copy(durationSec = (it.durationSec - 0.5f).coerceAtLeast(1f)) } }) { Icon(Icons.Filled.Remove, null) }
                        IconButton({ vm.updateScene(scene.id) { it.copy(durationSec = (it.durationSec + 0.5f).coerceAtMost(20f)) } }) { Icon(Icons.Filled.Add, null) }
                    }
                }
            }
        }

        // ---- generation ----
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = { vm.generateImages(false) }, enabled = st.busyText == null, modifier = Modifier.weight(1f)) {
                Icon(Icons.Filled.Image, null)
                Text(stringResource(R.string.generate_images), Modifier.padding(start = 6.dp), maxLines = 1)
            }
            OutlinedButton(onClick = { vm.prepareVoices() }, enabled = st.busyText == null, modifier = Modifier.weight(1f)) {
                Icon(Icons.Filled.RecordVoiceOver, null)
                Text(stringResource(R.string.generate_voice), Modifier.padding(start = 6.dp), maxLines = 1)
            }
        }
        OutlinedButton(onClick = { vm.generateImages(true) }, enabled = st.busyText == null, modifier = Modifier.fillMaxWidth()) {
            Text(stringResource(R.string.regenerate_all))
        }

        HorizontalDivider()

        // ---- subtitles ----
        val sub = p.subtitle
        SectionTitle(stringResource(R.string.subtitles))
        Text(stringResource(R.string.sub_font), style = MaterialTheme.typography.labelMedium)
        ChipRow(SubtitleFont.entries, sub.font, { v -> vm.setSubtitle(sub.copy(font = v)) }) { it.label() }
        Text(stringResource(R.string.sub_size, sub.size), style = MaterialTheme.typography.labelMedium)
        Slider(sub.size.toFloat(), { v -> vm.setSubtitle(sub.copy(size = v.roundToInt())) }, valueRange = 30f..90f)
        Text(stringResource(R.string.sub_position), style = MaterialTheme.typography.labelMedium)
        ChipRow(SubtitlePosition.entries, sub.position, { v -> vm.setSubtitle(sub.copy(position = v)) }) { it.label() }
        Text(stringResource(R.string.sub_look), style = MaterialTheme.typography.labelMedium)
        ChipRow(SubtitleLook.entries, sub.look, { v -> vm.setSubtitle(sub.copy(look = v)) }) { it.label() }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(stringResource(R.string.sub_background), Modifier.weight(1f))
            Switch(sub.background, { v -> vm.setSubtitle(sub.copy(background = v)) })
        }
        Text(stringResource(R.string.sub_animation), style = MaterialTheme.typography.labelMedium)
        ChipRow(SubtitleAnim.entries, sub.anim, { v -> vm.setSubtitle(sub.copy(anim = v)) }) { it.label() }

        HorizontalDivider()

        // ---- export ----
        SectionTitle(stringResource(R.string.export_section))
        ChipRow(AspectFormat.entries, p.format, { f -> vm.setFormat(f) }) { "${it.label}  ${it.w}×${it.h}" }
        Text(stringResource(R.string.export_note), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Button(onClick = { vm.export() }, enabled = st.busyText == null, modifier = Modifier.fillMaxWidth().height(52.dp)) {
            Icon(Icons.Filled.Movie, null)
            Text(stringResource(R.string.export_video), Modifier.padding(start = 8.dp), fontWeight = FontWeight.Black)
        }
        val uri = st.export?.uri
        if (uri != null) {
            OutlinedButton(
                onClick = {
                    val i = Intent(Intent.ACTION_VIEW).setDataAndType(uri, "video/mp4").addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    runCatching { ctx.startActivity(i) }
                },
                modifier = Modifier.fillMaxWidth(),
            ) { Text(stringResource(R.string.open_video)) }
        }
    }
}
