package com.sketchai.app.ai

import com.sketchai.app.domain.Character
import com.sketchai.app.domain.Scene

/** Single place where the black & white sketch style is injected into every generation request. */
object StylePromptBuilder {
    val STYLE_TAGS = listOf(
        "black and white minimalist hand drawn sketch",
        "clean black ink outlines",
        "white background",
        "simple cartoon line art",
        "consistent character design",
        "minimal shading",
        "no color",
        "no photorealism",
    )

    const val NEGATIVE =
        "color, colour, photorealistic, photograph, 3d render, gradient, heavy shading, texture, " +
            "text, letters, watermark, signature, blurry, complex background"

    fun styleSuffix(): String = STYLE_TAGS.joinToString(", ")

    fun scenePrompt(scene: Scene, characters: List<Character>): String {
        val inScene = scene.characterIds.mapNotNull { id -> characters.find { it.id == id } }
        val who = inScene.joinToString("; ") { it.promptDescription() }
        val parts = buildList {
            if (scene.action.isNotBlank()) add(scene.action.trim())
            if (who.isNotBlank()) add("characters: $who")
            add("full body shot, simple composition, lots of white space")
            add(styleSuffix())
        }
        return parts.joinToString(". ")
    }

    fun characterPrompt(c: Character): String =
        "character design sheet, ${c.promptDescription()}, front view, ${styleSuffix()}"
}
