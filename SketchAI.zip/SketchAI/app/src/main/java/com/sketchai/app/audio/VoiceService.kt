package com.sketchai.app.audio

import com.sketchai.app.data.AppSettings
import com.sketchai.app.domain.VoiceProfile
import com.sketchai.app.network.AiException
import kotlinx.coroutines.CancellationException
import java.io.File

/** Picks remote TTS when configured, falls back to the local Android engine. */
class VoiceService(
    private val settings: () -> AppSettings,
    private val local: VoiceGenerationProvider,
    private val remote: VoiceGenerationProvider,
) {
    private fun useRemote(): Boolean = settings().let { it.remoteTts && it.backendConfigured }

    /** Stable cache key: same text + same voice + same engine -> same file. */
    fun keyFor(text: String, voice: VoiceProfile): String {
        val s = settings()
        val raw = "${if (useRemote()) "r:${s.ttsModel}" else "a:${s.language}"}|$text|${voice.pitch}|${voice.rate}|${voice.remoteVoice}"
        return raw.hashCode().toUInt().toString(16)
    }

    fun fileFor(dir: File, text: String, voice: VoiceProfile): File = File(dir, "v_${keyFor(text, voice)}.wav")

    suspend fun synthesize(text: String, voice: VoiceProfile, dir: File): File {
        val file = fileFor(dir, text, voice)
        if (file.exists() && file.length() > 44) return file
        if (useRemote()) {
            try {
                return remote.synthesize(text, voice, file)
            } catch (e: CancellationException) {
                throw e
            } catch (e: AiException) {
                file.delete() // fall through to the local engine
            }
        }
        return local.synthesize(text, voice, file)
    }
}
