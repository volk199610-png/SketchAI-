package com.sketchai.app.ai

import com.sketchai.app.domain.Character
import com.sketchai.app.domain.VoicePreset

object CharacterFactory {

    private val hairs = listOf("short messy hair", "bald head", "long straight hair", "curly hair", "spiky hair")
    private val clothes = listOf("plain shirt and trousers", "long coat", "dress", "hoodie", "suit and tie")
    private val accessories = listOf("round glasses", "", "small hat", "", "tie")

    private const val CYR = "абвгдеёжзийклмнопрстуфхцчшщъыьэюя"
    private val LAT = listOf(
        "a", "b", "v", "g", "d", "e", "e", "zh", "z", "i", "y", "k", "l", "m", "n", "o", "p", "r", "s", "t",
        "u", "f", "kh", "ts", "ch", "sh", "sch", "", "y", "", "e", "yu", "ya",
    )

    /** DOCTOR_01 style identifier. Cyrillic names are transliterated. */
    fun idFor(name: String, index: Int): String {
        val sb = StringBuilder()
        for (ch in name.lowercase()) {
            val i = CYR.indexOf(ch)
            if (i >= 0) sb.append(LAT[i]) else sb.append(ch)
        }
        val slug = sb.toString().uppercase().replace(Regex("[^A-Z0-9]+"), "_").trim('_').ifEmpty { "CHAR" }
        return slug + "_" + (index + 1).toString().padStart(2, '0')
    }

    fun voiceFor(gender: String, personality: String, index: Int, defaultVoice: Int): VoicePreset {
        val female = gender.trim().lowercase().let { it.startsWith("f") || it.startsWith("ж") || it.contains("woman") }
        val nervous = personality.lowercase().let { p -> listOf("nerv", "anx", "panic", "тревож", "нерв").any { p.contains(it) } }
        return when {
            female && nervous -> VoicePreset.FEMALE_BRIGHT
            female -> VoicePreset.FEMALE_CALM
            nervous -> VoicePreset.MALE_NERVOUS
            index == 0 -> VoicePreset.entries[defaultVoice.coerceIn(0, VoicePreset.entries.size - 1)]
            else -> VoicePreset.MALE_CALM
        }
    }

    fun default(index: Int, name: String, defaultVoice: Int): Character {
        val preset = voiceFor("male", "", index, defaultVoice)
        return Character(
            id = idFor(name, index),
            name = name,
            gender = "male",
            age = "35",
            hair = hairs[index % hairs.size],
            face = "round face, dot eyes, small mouth",
            body = "thin body",
            clothes = clothes[index % clothes.size],
            accessories = accessories[index % accessories.size],
            personality = "calm",
            visualDescription = "",
            voice = preset.toProfile(),
        )
    }
}
