package com.sketchai.app.ai

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import com.sketchai.app.data.AppSettings
import com.sketchai.app.network.AiException
import com.sketchai.app.network.ApiClient
import kotlinx.coroutines.delay
import kotlinx.coroutines.ensureActive
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.jsonArray
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import kotlinx.serialization.json.put
import java.net.URLEncoder
import java.util.UUID
import kotlin.coroutines.coroutineContext

/**
 * ComfyUI HTTP API: POST /prompt -> poll /history/{id} -> GET /view.
 * The workflow is an API-format JSON with placeholders:
 * %PROMPT% %NEGATIVE% %WIDTH% %HEIGHT% %SEED% %CHECKPOINT%
 */
class ComfyUiImageProvider(
    private val api: ApiClient,
    private val json: Json,
    private val settings: () -> AppSettings,
) : ImageGenerationProvider {

    override val name = "ComfyUI"

    override suspend fun generateImage(request: ImageRequest): Bitmap {
        val s = settings()
        if (!s.comfyConfigured) throw AiException(AiException.Kind.NOT_CONFIGURED, "ComfyUI URL is empty")

        val template = s.comfyWorkflow.ifBlank { DEFAULT_WORKFLOW }
        val workflow = template
            .replace("%PROMPT%", escape(request.prompt))
            .replace("%NEGATIVE%", escape(request.negativePrompt))
            .replace("%CHECKPOINT%", escape(s.comfyCheckpoint))
            .replace("%WIDTH%", request.format.genW.toString())
            .replace("%HEIGHT%", request.format.genH.toString())
            .replace("%SEED%", request.seed.toString())

        val workflowJson = try {
            json.parseToJsonElement(workflow).jsonObject
        } catch (e: Exception) {
            throw AiException(AiException.Kind.INVALID_RESPONSE, "Workflow JSON is invalid: ${e.message}")
        }
        val payload = buildJsonObject {
            put("client_id", UUID.randomUUID().toString())
            put("prompt", workflowJson)
        }.toString()

        val base = s.comfyUrl
        val submit = api.postJson(ApiClient.join(base, "prompt"), payload)
        val promptId = try {
            json.parseToJsonElement(submit).jsonObject["prompt_id"]!!.jsonPrimitive.content
        } catch (e: Exception) {
            throw AiException(AiException.Kind.INVALID_RESPONSE, "ComfyUI did not return prompt_id")
        }

        // Poll for up to ~4 minutes.
        repeat(240) {
            coroutineContext.ensureActive()
            delay(1000)
            val hist = api.getString(ApiClient.join(base, "history/$promptId"))
            val entry = json.parseToJsonElement(hist).jsonObject[promptId] as? JsonObject
            if (entry != null) {
                val file = findImage(entry)
                    ?: throw AiException(AiException.Kind.GENERATION_FAILED, "ComfyUI finished without an image")
                val url = ApiClient.join(base, "view") + "?filename=${enc(file.first)}&subfolder=${enc(file.second)}&type=${enc(file.third)}"
                val bytes = api.getBytes(url)
                return BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
                    ?: throw AiException(AiException.Kind.INVALID_RESPONSE, "Cannot decode image")
            }
        }
        throw AiException(AiException.Kind.TIMEOUT, "ComfyUI generation took too long")
    }

    private fun findImage(entry: JsonObject): Triple<String, String, String>? {
        val outputs = entry["outputs"] as? JsonObject ?: return null
        for ((_, node) in outputs) {
            val images = (node as? JsonObject)?.get("images")?.jsonArray ?: continue
            val first = images.firstOrNull()?.jsonObject ?: continue
            return Triple(
                first["filename"]?.jsonPrimitive?.content ?: continue,
                first["subfolder"]?.jsonPrimitive?.content.orEmpty(),
                first["type"]?.jsonPrimitive?.content ?: "output",
            )
        }
        return null
    }

    private fun enc(v: String) = URLEncoder.encode(v, "UTF-8")

    /** JSON-escape a string so it can be dropped between quotes of the template. */
    private fun escape(v: String): String = JsonPrimitive(v).toString().let { it.substring(1, it.length - 1) }

    companion object {
        const val DEFAULT_WORKFLOW = """{
  "3": {"class_type": "KSampler", "inputs": {"seed": %SEED%, "steps": 25, "cfg": 7, "sampler_name": "euler", "scheduler": "normal", "denoise": 1, "model": ["4", 0], "positive": ["6", 0], "negative": ["7", 0], "latent_image": ["5", 0]}},
  "4": {"class_type": "CheckpointLoaderSimple", "inputs": {"ckpt_name": "%CHECKPOINT%"}},
  "5": {"class_type": "EmptyLatentImage", "inputs": {"width": %WIDTH%, "height": %HEIGHT%, "batch_size": 1}},
  "6": {"class_type": "CLIPTextEncode", "inputs": {"text": "%PROMPT%", "clip": ["4", 1]}},
  "7": {"class_type": "CLIPTextEncode", "inputs": {"text": "%NEGATIVE%", "clip": ["4", 1]}},
  "8": {"class_type": "VAEDecode", "inputs": {"samples": ["3", 0], "vae": ["4", 2]}},
  "9": {"class_type": "SaveImage", "inputs": {"filename_prefix": "sketchai", "images": ["8", 0]}}
}"""
    }
}
